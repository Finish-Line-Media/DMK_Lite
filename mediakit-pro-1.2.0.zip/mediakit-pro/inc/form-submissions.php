<?php
/**
 * Form Submissions Admin Interface
 *
 * @package MediaKit_Pro
 */

// This file has been emptied as form submissions functionality has been removed