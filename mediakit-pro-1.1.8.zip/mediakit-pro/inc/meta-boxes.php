<?php
/**
 * Custom Meta Boxes for MediaKit Pro
 *
 * @package MediaKit_Pro
 */

// This file has been emptied as the custom post types have been removed