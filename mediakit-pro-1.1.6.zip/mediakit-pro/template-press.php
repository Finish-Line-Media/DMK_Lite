<?php
/**
 * Template Name: Press/Media
 * Template Post Type: page
 * Description: Media appearances and press features
 *
 * @package MediaKit_Pro
 */

get_header();
?>

<main id="primary" class="mkp-main mkp-main--press">
    
    <?php while ( have_posts() ) : the_post(); ?>
        
        <!-- Page Header -->
        <section class="mkp-page-header mkp-page-header--centered">
            <div class="mkp-container">
                <h1 class="mkp-page-title"><?php the_title(); ?></h1>
                <?php if ( has_excerpt() ) : ?>
                    <div class="mkp-page-subtitle"><?php the_excerpt(); ?></div>
                <?php endif; ?>
            </div>
        </section>
        
        <!-- Page Content -->
        <?php if ( get_the_content() ) : ?>
            <section class="mkp-section">
                <div class="mkp-container">
                    <div class="mkp-press-intro">
                        <?php the_content(); ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
        
        <!-- Media Logos -->
        <?php if ( function_exists( 'get_field' ) && have_rows( 'media_logos', 'option' ) ) : ?>
            <section class="mkp-section mkp-section--alt">
                <div class="mkp-container">
                    <header class="mkp-section__header">
                        <h2 class="mkp-section__title"><?php esc_html_e( 'Featured In', 'mediakit-pro' ); ?></h2>
                    </header>
                    
                    <div class="mkp-media-logos mkp-media-logos--grayscale">
                        <div class="mkp-media-logos__grid">
                            <?php while ( have_rows( 'media_logos', 'option' ) ) : the_row(); ?>
                                <?php
                                $logo = get_sub_field( 'logo' );
                                $link = get_sub_field( 'link' );
                                
                                if ( $logo ) :
                                    ?>
                                    <div class="mkp-media-logos__item">
                                        <?php if ( $link ) : ?>
                                            <a href="<?php echo esc_url( $link ); ?>" target="_blank" rel="noopener noreferrer">
                                        <?php endif; ?>
                                        
                                        <img src="<?php echo esc_url( $logo['url'] ); ?>" 
                                             alt="<?php echo esc_attr( $logo['alt'] ); ?>" 
                                             class="mkp-media-logos__image">
                                        
                                        <?php if ( $link ) : ?>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif; ?>
        
        <!-- Media Appearances -->
        <section class="mkp-section">
            <div class="mkp-container">
                <header class="mkp-section__header">
                    <h2 class="mkp-section__title"><?php esc_html_e( 'Recent Media Appearances', 'mediakit-pro' ); ?></h2>
                </header>
                
                <?php
                $media_types = get_terms( array(
                    'taxonomy'   => 'media_type',
                    'hide_empty' => true,
                ) );
                
                // Create tabs for media types
                if ( ! empty( $media_types ) && ! is_wp_error( $media_types ) ) :
                    ?>
                    <div class="mkp-media-tabs">
                        <div class="mkp-media-tabs__nav">
                            <button class="mkp-media-tabs__button is-active" data-tab="all">
                                <?php esc_html_e( 'All Media', 'mediakit-pro' ); ?>
                            </button>
                            <?php foreach ( $media_types as $type ) : ?>
                                <button class="mkp-media-tabs__button" data-tab="<?php echo esc_attr( $type->slug ); ?>">
                                    <?php echo esc_html( $type->name ); ?>
                                </button>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="mkp-media-tabs__content">
                            <?php
                            $media_appearances = new WP_Query( array(
                                'post_type'      => 'media_appearance',
                                'posts_per_page' => -1,
                                'orderby'        => 'meta_value',
                                'meta_key'       => 'appearance_date',
                                'meta_type'      => 'DATE',
                                'order'          => 'DESC',
                            ) );
                            
                            if ( $media_appearances->have_posts() ) :
                                ?>
                                <div class="mkp-media-list">
                                    <?php
                                    while ( $media_appearances->have_posts() ) :
                                        $media_appearances->the_post();
                                        
                                        $media_type_terms = get_the_terms( get_the_ID(), 'media_type' );
                                        $media_type_class = 'all';
                                        
                                        if ( $media_type_terms && ! is_wp_error( $media_type_terms ) ) {
                                            $media_type_class .= ' ' . $media_type_terms[0]->slug;
                                        }
                                        ?>
                                        
                                        <article class="mkp-media-item" data-media-type="<?php echo esc_attr( $media_type_class ); ?>">
                                            <div class="mkp-media-item__date">
                                                <?php
                                                if ( function_exists( 'get_field' ) ) {
                                                    $date = get_field( 'appearance_date' );
                                                    if ( $date ) {
                                                        echo esc_html( date_i18n( 'F j, Y', strtotime( $date ) ) );
                                                    }
                                                }
                                                ?>
                                            </div>
                                            
                                            <div class="mkp-media-item__content">
                                                <h3 class="mkp-media-item__title">
                                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                                </h3>
                                                
                                                <?php if ( function_exists( 'get_field' ) ) : ?>
                                                    <?php
                                                    $outlet = get_field( 'outlet_name' );
                                                    if ( $outlet ) :
                                                        ?>
                                                        <div class="mkp-media-item__outlet">
                                                            <?php echo esc_html( $outlet ); ?>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                
                                                <?php if ( has_excerpt() ) : ?>
                                                    <div class="mkp-media-item__excerpt">
                                                        <?php the_excerpt(); ?>
                                                    </div>
                                                <?php endif; ?>
                                                
                                                <?php mkp_media_type_badge(); ?>
                                            </div>
                                            
                                            <?php if ( has_post_thumbnail() ) : ?>
                                                <div class="mkp-media-item__image">
                                                    <a href="<?php the_permalink(); ?>">
                                                        <?php the_post_thumbnail( 'thumbnail' ); ?>
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                        </article>
                                        
                                        <?php
                                    endwhile;
                                    wp_reset_postdata();
                                    ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        
        <!-- Press Mentions -->
        <?php
        $press_mentions = new WP_Query( array(
            'post_type'      => 'press_mention',
            'posts_per_page' => -1,
            'orderby'        => 'meta_value',
            'meta_key'       => 'publication_date',
            'meta_type'      => 'DATE',
            'order'          => 'DESC',
        ) );
        
        if ( $press_mentions->have_posts() ) :
            ?>
            <section class="mkp-section mkp-section--alt">
                <div class="mkp-container">
                    <header class="mkp-section__header">
                        <h2 class="mkp-section__title"><?php esc_html_e( 'Press Mentions', 'mediakit-pro' ); ?></h2>
                    </header>
                    
                    <div class="mkp-press-grid">
                        <?php
                        while ( $press_mentions->have_posts() ) :
                            $press_mentions->the_post();
                            ?>
                            
                            <article class="mkp-press-card">
                                <?php if ( function_exists( 'get_field' ) ) : ?>
                                    <?php
                                    $publication_logo = get_field( 'publication_logo' );
                                    if ( $publication_logo ) :
                                        ?>
                                        <div class="mkp-press-card__logo">
                                            <img src="<?php echo esc_url( $publication_logo['url'] ); ?>" 
                                                 alt="<?php echo esc_attr( $publication_logo['alt'] ); ?>">
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php
                                    $pull_quote = get_field( 'pull_quote' );
                                    if ( $pull_quote ) :
                                        ?>
                                        <blockquote class="mkp-press-card__quote">
                                            <?php echo esc_html( $pull_quote ); ?>
                                        </blockquote>
                                    <?php endif; ?>
                                    
                                    <div class="mkp-press-card__meta">
                                        <?php
                                        $publication = get_field( 'publication_name' );
                                        $article_title = get_field( 'article_title' );
                                        $article_link = get_field( 'article_link' );
                                        $pub_date = get_field( 'publication_date' );
                                        ?>
                                        
                                        <?php if ( $article_title && $article_link ) : ?>
                                            <h3 class="mkp-press-card__title">
                                                <a href="<?php echo esc_url( $article_link ); ?>" target="_blank" rel="noopener noreferrer">
                                                    <?php echo esc_html( $article_title ); ?>
                                                </a>
                                            </h3>
                                        <?php endif; ?>
                                        
                                        <div class="mkp-press-card__publication">
                                            <?php
                                            if ( $publication ) {
                                                echo esc_html( $publication );
                                            }
                                            if ( $pub_date ) {
                                                echo ' • ' . esc_html( date_i18n( 'F Y', strtotime( $pub_date ) ) );
                                            }
                                            ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </article>
                            
                            <?php
                        endwhile;
                        wp_reset_postdata();
                        ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
        
        <!-- Press Kit Download -->
        <section class="mkp-section mkp-press-kit">
            <div class="mkp-container">
                <div class="mkp-press-kit__content">
                    <h2><?php esc_html_e( 'Press & Media Resources', 'mediakit-pro' ); ?></h2>
                    <p><?php esc_html_e( 'Download high-resolution photos, bios, and interview resources.', 'mediakit-pro' ); ?></p>
                    
                    <div class="mkp-press-kit__buttons">
                        <a href="#download-resources" class="mkp-btn mkp-btn--primary">
                            <?php esc_html_e( 'Download Press Kit', 'mediakit-pro' ); ?>
                        </a>
                        
                        <?php
                        $press_email = get_theme_mod( 'mkp_contact_email_press' );
                        if ( $press_email ) :
                            ?>
                            <a href="mailto:<?php echo esc_attr( $press_email ); ?>" class="mkp-btn mkp-btn--secondary">
                                <?php esc_html_e( 'Media Inquiries', 'mediakit-pro' ); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
        
    <?php endwhile; ?>
    
</main>

<?php
get_footer();