<?php
/**
 * Form Submissions Admin Interface
 *
 * @package MediaKit_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Add form submissions menu page
 */
function mkp_add_form_submissions_menu() {
    add_submenu_page(
        'mediakit-pro',
        __( 'Form Submissions', 'mediakit-pro' ),
        __( 'Form Submissions', 'mediakit-pro' ),
        'manage_options',
        'mkp-form-submissions',
        'mkp_form_submissions_page'
    );
}
add_action( 'admin_menu', 'mkp_add_form_submissions_menu', 25 );

/**
 * Display form submissions page
 */
function mkp_form_submissions_page() {
    // Handle actions
    if ( isset( $_GET['action'] ) && isset( $_GET['submission'] ) ) {
        $action = $_GET['action'];
        $submission_id = intval( $_GET['submission'] );
        
        if ( $action === 'delete' && wp_verify_nonce( $_GET['_wpnonce'], 'delete_submission_' . $submission_id ) ) {
            mkp_delete_form_submission( $submission_id );
            wp_redirect( admin_url( 'admin.php?page=mkp-form-submissions&deleted=1' ) );
            exit;
        } elseif ( $action === 'mark-read' && wp_verify_nonce( $_GET['_wpnonce'], 'mark_read_' . $submission_id ) ) {
            mkp_update_submission_status( $submission_id, 'read' );
            wp_redirect( admin_url( 'admin.php?page=mkp-form-submissions&updated=1' ) );
            exit;
        } elseif ( $action === 'mark-unread' && wp_verify_nonce( $_GET['_wpnonce'], 'mark_unread_' . $submission_id ) ) {
            mkp_update_submission_status( $submission_id, 'unread' );
            wp_redirect( admin_url( 'admin.php?page=mkp-form-submissions&updated=1' ) );
            exit;
        }
    }
    
    // Handle bulk actions
    if ( isset( $_POST['action'] ) && $_POST['action'] !== '-1' && isset( $_POST['submissions'] ) && isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'bulk-submissions' ) ) {
        $action = $_POST['action'];
        $submission_ids = array_map( 'intval', $_POST['submissions'] );
        
        foreach ( $submission_ids as $submission_id ) {
            if ( $action === 'delete' ) {
                mkp_delete_form_submission( $submission_id );
            } elseif ( $action === 'mark-read' ) {
                mkp_update_submission_status( $submission_id, 'read' );
            } elseif ( $action === 'mark-unread' ) {
                mkp_update_submission_status( $submission_id, 'unread' );
            }
        }
        
        wp_redirect( admin_url( 'admin.php?page=mkp-form-submissions&bulk_action=1' ) );
        exit;
    }
    
    // Show individual submission if requested
    if ( isset( $_GET['view'] ) ) {
        mkp_display_single_submission( intval( $_GET['view'] ) );
        return;
    }
    
    // Display submissions list
    mkp_display_submissions_list();
}

/**
 * Display submissions list
 */
function mkp_display_submissions_list() {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'mkp_form_submissions';
    
    // Get filter parameters
    $form_type = isset( $_GET['form_type'] ) ? sanitize_text_field( $_GET['form_type'] ) : '';
    $status = isset( $_GET['status'] ) ? sanitize_text_field( $_GET['status'] ) : '';
    $search = isset( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : '';
    
    // Build query
    $where = array( '1=1' );
    
    if ( $form_type ) {
        $where[] = $wpdb->prepare( 'form_type = %s', $form_type );
    }
    
    if ( $status ) {
        $where[] = $wpdb->prepare( 'status = %s', $status );
    }
    
    if ( $search ) {
        $where[] = $wpdb->prepare( '(name LIKE %s OR email LIKE %s OR message LIKE %s)', '%' . $search . '%', '%' . $search . '%', '%' . $search . '%' );
    }
    
    $where_clause = implode( ' AND ', $where );
    
    // Pagination
    $per_page = 20;
    $current_page = isset( $_GET['paged'] ) ? max( 1, intval( $_GET['paged'] ) ) : 1;
    $offset = ( $current_page - 1 ) * $per_page;
    
    // Get total count
    $total_items = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name WHERE $where_clause" );
    $total_pages = ceil( $total_items / $per_page );
    
    // Get submissions
    $submissions = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM $table_name WHERE $where_clause ORDER BY submission_date DESC LIMIT %d OFFSET %d",
        $per_page,
        $offset
    ) );
    
    // Get counts by status
    $status_counts = $wpdb->get_results(
        "SELECT status, COUNT(*) as count FROM $table_name GROUP BY status",
        OBJECT_K
    );
    
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline"><?php esc_html_e( 'Form Submissions', 'mediakit-pro' ); ?></h1>
        
        <?php if ( isset( $_GET['deleted'] ) ) : ?>
            <div class="notice notice-success is-dismissible">
                <p><?php esc_html_e( 'Submission deleted successfully.', 'mediakit-pro' ); ?></p>
            </div>
        <?php endif; ?>
        
        <?php if ( isset( $_GET['updated'] ) ) : ?>
            <div class="notice notice-success is-dismissible">
                <p><?php esc_html_e( 'Submission updated successfully.', 'mediakit-pro' ); ?></p>
            </div>
        <?php endif; ?>
        
        <?php if ( isset( $_GET['bulk_action'] ) ) : ?>
            <div class="notice notice-success is-dismissible">
                <p><?php esc_html_e( 'Bulk action completed successfully.', 'mediakit-pro' ); ?></p>
            </div>
        <?php endif; ?>
        
        <!-- Status filters -->
        <ul class="subsubsub">
            <li class="all">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mkp-form-submissions' ) ); ?>" <?php echo empty( $status ) ? 'class="current"' : ''; ?>>
                    <?php esc_html_e( 'All', 'mediakit-pro' ); ?>
                    <span class="count">(<?php echo esc_html( $total_items ); ?>)</span>
                </a> |
            </li>
            <li class="unread">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mkp-form-submissions&status=unread' ) ); ?>" <?php echo $status === 'unread' ? 'class="current"' : ''; ?>>
                    <?php esc_html_e( 'Unread', 'mediakit-pro' ); ?>
                    <span class="count">(<?php echo esc_html( $status_counts['unread']->count ?? 0 ); ?>)</span>
                </a> |
            </li>
            <li class="read">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=mkp-form-submissions&status=read' ) ); ?>" <?php echo $status === 'read' ? 'class="current"' : ''; ?>>
                    <?php esc_html_e( 'Read', 'mediakit-pro' ); ?>
                    <span class="count">(<?php echo esc_html( $status_counts['read']->count ?? 0 ); ?>)</span>
                </a>
            </li>
        </ul>
        
        <form method="get">
            <input type="hidden" name="page" value="mkp-form-submissions">
            <?php if ( $status ) : ?>
                <input type="hidden" name="status" value="<?php echo esc_attr( $status ); ?>">
            <?php endif; ?>
            
            <p class="search-box">
                <label class="screen-reader-text" for="submission-search-input"><?php esc_html_e( 'Search submissions', 'mediakit-pro' ); ?></label>
                <input type="search" id="submission-search-input" name="s" value="<?php echo esc_attr( $search ); ?>">
                <input type="submit" id="search-submit" class="button" value="<?php esc_attr_e( 'Search', 'mediakit-pro' ); ?>">
            </p>
        </form>
        
        <form method="post">
            <?php wp_nonce_field( 'bulk-submissions' ); ?>
            
            <div class="tablenav top">
                <div class="alignleft actions bulkactions">
                    <select name="action">
                        <option value="-1"><?php esc_html_e( 'Bulk Actions', 'mediakit-pro' ); ?></option>
                        <option value="mark-read"><?php esc_html_e( 'Mark as Read', 'mediakit-pro' ); ?></option>
                        <option value="mark-unread"><?php esc_html_e( 'Mark as Unread', 'mediakit-pro' ); ?></option>
                        <option value="delete"><?php esc_html_e( 'Delete', 'mediakit-pro' ); ?></option>
                    </select>
                    <input type="submit" class="button action" value="<?php esc_attr_e( 'Apply', 'mediakit-pro' ); ?>">
                </div>
                
                <div class="alignleft actions">
                    <select name="form_type" onchange="this.form.submit()">
                        <option value=""><?php esc_html_e( 'All Form Types', 'mediakit-pro' ); ?></option>
                        <option value="general" <?php selected( $form_type, 'general' ); ?>><?php esc_html_e( 'General Contact', 'mediakit-pro' ); ?></option>
                        <option value="booking" <?php selected( $form_type, 'booking' ); ?>><?php esc_html_e( 'Booking Requests', 'mediakit-pro' ); ?></option>
                        <option value="media" <?php selected( $form_type, 'media' ); ?>><?php esc_html_e( 'Media Inquiries', 'mediakit-pro' ); ?></option>
                    </select>
                </div>
                
                <?php if ( $total_pages > 1 ) : ?>
                    <div class="tablenav-pages">
                        <?php
                        echo paginate_links( array(
                            'base' => add_query_arg( 'paged', '%#%' ),
                            'format' => '',
                            'prev_text' => '&laquo;',
                            'next_text' => '&raquo;',
                            'total' => $total_pages,
                            'current' => $current_page,
                        ) );
                        ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <td class="manage-column column-cb check-column">
                            <input type="checkbox" id="cb-select-all-1">
                        </td>
                        <th scope="col" class="manage-column"><?php esc_html_e( 'Name', 'mediakit-pro' ); ?></th>
                        <th scope="col" class="manage-column"><?php esc_html_e( 'Email', 'mediakit-pro' ); ?></th>
                        <th scope="col" class="manage-column"><?php esc_html_e( 'Type', 'mediakit-pro' ); ?></th>
                        <th scope="col" class="manage-column"><?php esc_html_e( 'Message', 'mediakit-pro' ); ?></th>
                        <th scope="col" class="manage-column"><?php esc_html_e( 'Date', 'mediakit-pro' ); ?></th>
                        <th scope="col" class="manage-column"><?php esc_html_e( 'Status', 'mediakit-pro' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $submissions ) ) : ?>
                        <tr>
                            <td colspan="7" class="no-items"><?php esc_html_e( 'No submissions found.', 'mediakit-pro' ); ?></td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ( $submissions as $submission ) : ?>
                            <tr class="<?php echo $submission->status === 'unread' ? 'unread' : ''; ?>">
                                <th scope="row" class="check-column">
                                    <input type="checkbox" name="submissions[]" value="<?php echo esc_attr( $submission->id ); ?>">
                                </th>
                                <td class="column-name">
                                    <strong>
                                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=mkp-form-submissions&view=' . $submission->id ) ); ?>">
                                            <?php echo esc_html( $submission->name ); ?>
                                        </a>
                                    </strong>
                                    <div class="row-actions">
                                        <span class="view">
                                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=mkp-form-submissions&view=' . $submission->id ) ); ?>">
                                                <?php esc_html_e( 'View', 'mediakit-pro' ); ?>
                                            </a> |
                                        </span>
                                        <?php if ( $submission->status === 'unread' ) : ?>
                                            <span class="mark-read">
                                                <a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=mkp-form-submissions&action=mark-read&submission=' . $submission->id ), 'mark_read_' . $submission->id ); ?>">
                                                    <?php esc_html_e( 'Mark as Read', 'mediakit-pro' ); ?>
                                                </a> |
                                            </span>
                                        <?php else : ?>
                                            <span class="mark-unread">
                                                <a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=mkp-form-submissions&action=mark-unread&submission=' . $submission->id ), 'mark_unread_' . $submission->id ); ?>">
                                                    <?php esc_html_e( 'Mark as Unread', 'mediakit-pro' ); ?>
                                                </a> |
                                            </span>
                                        <?php endif; ?>
                                        <span class="trash">
                                            <a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=mkp-form-submissions&action=delete&submission=' . $submission->id ), 'delete_submission_' . $submission->id ); ?>" class="submitdelete" onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to delete this submission?', 'mediakit-pro' ); ?>');">
                                                <?php esc_html_e( 'Delete', 'mediakit-pro' ); ?>
                                            </a>
                                        </span>
                                    </div>
                                </td>
                                <td><?php echo esc_html( $submission->email ); ?></td>
                                <td>
                                    <?php
                                    $type_labels = array(
                                        'general' => __( 'General', 'mediakit-pro' ),
                                        'booking' => __( 'Booking', 'mediakit-pro' ),
                                        'media' => __( 'Media', 'mediakit-pro' ),
                                    );
                                    echo esc_html( $type_labels[ $submission->form_type ] ?? $submission->form_type );
                                    ?>
                                </td>
                                <td><?php echo esc_html( wp_trim_words( $submission->message, 15 ) ); ?></td>
                                <td><?php echo esc_html( human_time_diff( strtotime( $submission->submission_date ), current_time( 'timestamp' ) ) . ' ' . __( 'ago', 'mediakit-pro' ) ); ?></td>
                                <td>
                                    <span class="submission-status submission-status-<?php echo esc_attr( $submission->status ); ?>">
                                        <?php echo esc_html( ucfirst( $submission->status ) ); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </form>
    </div>
    
    <style>
        .submission-status {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 12px;
        }
        .submission-status-unread {
            background: #d63638;
            color: white;
        }
        .submission-status-read {
            background: #00a32a;
            color: white;
        }
        tr.unread td {
            font-weight: 600;
        }
    </style>
    <?php
}

/**
 * Display single submission
 */
function mkp_display_single_submission( $submission_id ) {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'mkp_form_submissions';
    $submission = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d", $submission_id ) );
    
    if ( ! $submission ) {
        wp_die( __( 'Submission not found.', 'mediakit-pro' ) );
    }
    
    // Mark as read
    if ( $submission->status === 'unread' ) {
        mkp_update_submission_status( $submission_id, 'read' );
    }
    
    $form_data = json_decode( $submission->form_data, true );
    
    // Handle note update
    if ( isset( $_POST['submit_note'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'update_submission_note' ) ) {
        $notes = sanitize_textarea_field( $_POST['submission_notes'] );
        $wpdb->update(
            $table_name,
            array( 'notes' => $notes ),
            array( 'id' => $submission_id ),
            array( '%s' ),
            array( '%d' )
        );
        echo '<div class="notice notice-success"><p>' . esc_html__( 'Notes updated successfully.', 'mediakit-pro' ) . '</p></div>';
        $submission->notes = $notes;
    }
    
    ?>
    <div class="wrap">
        <h1>
            <?php esc_html_e( 'View Submission', 'mediakit-pro' ); ?>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=mkp-form-submissions' ) ); ?>" class="page-title-action">
                <?php esc_html_e( 'Back to List', 'mediakit-pro' ); ?>
            </a>
        </h1>
        
        <div id="poststuff">
            <div id="post-body" class="metabox-holder columns-2">
                <div id="post-body-content">
                    <div class="postbox">
                        <h2 class="hndle"><?php esc_html_e( 'Submission Details', 'mediakit-pro' ); ?></h2>
                        <div class="inside">
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Name', 'mediakit-pro' ); ?></th>
                                    <td><?php echo esc_html( $submission->name ); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Email', 'mediakit-pro' ); ?></th>
                                    <td>
                                        <a href="mailto:<?php echo esc_attr( $submission->email ); ?>">
                                            <?php echo esc_html( $submission->email ); ?>
                                        </a>
                                    </td>
                                </tr>
                                
                                <?php if ( $submission->form_type === 'booking' && $form_data ) : ?>
                                    <tr>
                                        <th scope="row"><?php esc_html_e( 'Organization', 'mediakit-pro' ); ?></th>
                                        <td><?php echo esc_html( $form_data['organization'] ?? '' ); ?></td>
                                    </tr>
                                    <?php if ( ! empty( $form_data['phone'] ) ) : ?>
                                        <tr>
                                            <th scope="row"><?php esc_html_e( 'Phone', 'mediakit-pro' ); ?></th>
                                            <td><?php echo esc_html( $form_data['phone'] ); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <th scope="row"><?php esc_html_e( 'Event Date', 'mediakit-pro' ); ?></th>
                                        <td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $form_data['event_date'] ) ) ); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><?php esc_html_e( 'Event Type', 'mediakit-pro' ); ?></th>
                                        <td><?php echo esc_html( ucfirst( $form_data['event_type'] ) ); ?></td>
                                    </tr>
                                    <?php if ( ! empty( $form_data['location'] ) ) : ?>
                                        <tr>
                                            <th scope="row"><?php esc_html_e( 'Location', 'mediakit-pro' ); ?></th>
                                            <td><?php echo esc_html( $form_data['location'] ); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    
                                <?php elseif ( $submission->form_type === 'media' && $form_data ) : ?>
                                    <tr>
                                        <th scope="row"><?php esc_html_e( 'Media Outlet', 'mediakit-pro' ); ?></th>
                                        <td><?php echo esc_html( $form_data['media_outlet'] ?? '' ); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><?php esc_html_e( 'Inquiry Type', 'mediakit-pro' ); ?></th>
                                        <td><?php echo esc_html( ucfirst( str_replace( '_', ' ', $form_data['inquiry_type'] ?? '' ) ) ); ?></td>
                                    </tr>
                                    <?php if ( ! empty( $form_data['deadline'] ) ) : ?>
                                        <tr>
                                            <th scope="row"><?php esc_html_e( 'Deadline', 'mediakit-pro' ); ?></th>
                                            <td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $form_data['deadline'] ) ) ); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    
                                <?php elseif ( $form_data && isset( $form_data['subject'] ) ) : ?>
                                    <tr>
                                        <th scope="row"><?php esc_html_e( 'Subject', 'mediakit-pro' ); ?></th>
                                        <td><?php echo esc_html( $form_data['subject'] ); ?></td>
                                    </tr>
                                <?php endif; ?>
                                
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Message', 'mediakit-pro' ); ?></th>
                                    <td>
                                        <div style="background: #f9f9f9; padding: 15px; border: 1px solid #e1e1e1; border-radius: 4px;">
                                            <?php echo nl2br( esc_html( $submission->message ) ); ?>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    
                    <div class="postbox">
                        <h2 class="hndle"><?php esc_html_e( 'Internal Notes', 'mediakit-pro' ); ?></h2>
                        <div class="inside">
                            <form method="post">
                                <?php wp_nonce_field( 'update_submission_note' ); ?>
                                <textarea name="submission_notes" rows="5" class="large-text"><?php echo esc_textarea( $submission->notes ?? '' ); ?></textarea>
                                <p class="submit">
                                    <input type="submit" name="submit_note" class="button button-primary" value="<?php esc_attr_e( 'Update Notes', 'mediakit-pro' ); ?>">
                                </p>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div id="postbox-container-1" class="postbox-container">
                    <div class="postbox">
                        <h2 class="hndle"><?php esc_html_e( 'Submission Info', 'mediakit-pro' ); ?></h2>
                        <div class="inside">
                            <div class="misc-pub-section">
                                <strong><?php esc_html_e( 'Status:', 'mediakit-pro' ); ?></strong>
                                <span class="submission-status submission-status-<?php echo esc_attr( $submission->status ); ?>">
                                    <?php echo esc_html( ucfirst( $submission->status ) ); ?>
                                </span>
                            </div>
                            
                            <div class="misc-pub-section">
                                <strong><?php esc_html_e( 'Form Type:', 'mediakit-pro' ); ?></strong>
                                <?php
                                $type_labels = array(
                                    'general' => __( 'General Contact', 'mediakit-pro' ),
                                    'booking' => __( 'Booking Request', 'mediakit-pro' ),
                                    'media' => __( 'Media Inquiry', 'mediakit-pro' ),
                                );
                                echo esc_html( $type_labels[ $submission->form_type ] ?? $submission->form_type );
                                ?>
                            </div>
                            
                            <div class="misc-pub-section">
                                <strong><?php esc_html_e( 'Submitted:', 'mediakit-pro' ); ?></strong><br>
                                <?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $submission->submission_date ) ) ); ?>
                            </div>
                            
                            <?php if ( $submission->ip_address ) : ?>
                                <div class="misc-pub-section">
                                    <strong><?php esc_html_e( 'IP Address:', 'mediakit-pro' ); ?></strong><br>
                                    <?php echo esc_html( $submission->ip_address ); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="postbox">
                        <h2 class="hndle"><?php esc_html_e( 'Actions', 'mediakit-pro' ); ?></h2>
                        <div class="inside">
                            <p>
                                <a href="mailto:<?php echo esc_attr( $submission->email ); ?>" class="button button-primary">
                                    <?php esc_html_e( 'Reply via Email', 'mediakit-pro' ); ?>
                                </a>
                            </p>
                            
                            <?php if ( $submission->status === 'unread' ) : ?>
                                <p>
                                    <a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=mkp-form-submissions&action=mark-read&submission=' . $submission->id ), 'mark_read_' . $submission->id ); ?>" class="button">
                                        <?php esc_html_e( 'Mark as Read', 'mediakit-pro' ); ?>
                                    </a>
                                </p>
                            <?php else : ?>
                                <p>
                                    <a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=mkp-form-submissions&action=mark-unread&submission=' . $submission->id ), 'mark_unread_' . $submission->id ); ?>" class="button">
                                        <?php esc_html_e( 'Mark as Unread', 'mediakit-pro' ); ?>
                                    </a>
                                </p>
                            <?php endif; ?>
                            
                            <p>
                                <a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=mkp-form-submissions&action=delete&submission=' . $submission->id ), 'delete_submission_' . $submission->id ); ?>" class="button button-link-delete" onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to delete this submission?', 'mediakit-pro' ); ?>');">
                                    <?php esc_html_e( 'Delete Submission', 'mediakit-pro' ); ?>
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}

/**
 * Delete form submission
 */
function mkp_delete_form_submission( $submission_id ) {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'mkp_form_submissions';
    $wpdb->delete( $table_name, array( 'id' => $submission_id ), array( '%d' ) );
}

/**
 * Update submission status
 */
function mkp_update_submission_status( $submission_id, $status ) {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'mkp_form_submissions';
    $wpdb->update(
        $table_name,
        array( 'status' => $status ),
        array( 'id' => $submission_id ),
        array( '%s' ),
        array( '%d' )
    );
}

/**
 * Add unread count to menu
 */
function mkp_add_submission_count_to_menu() {
    global $wpdb, $submenu;
    
    $table_name = $wpdb->prefix . 'mkp_form_submissions';
    $unread_count = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name WHERE status = 'unread'" );
    
    if ( $unread_count > 0 && isset( $submenu['mediakit-pro'] ) ) {
        foreach ( $submenu['mediakit-pro'] as $key => $item ) {
            if ( $item[2] === 'mkp-form-submissions' ) {
                $submenu['mediakit-pro'][$key][0] .= ' <span class="update-plugins count-' . $unread_count . '"><span class="plugin-count">' . $unread_count . '</span></span>';
                break;
            }
        }
    }
}
add_action( 'admin_menu', 'mkp_add_submission_count_to_menu', 100 );