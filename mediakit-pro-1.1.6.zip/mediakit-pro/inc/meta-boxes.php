<?php
/**
 * Custom Meta Boxes for MediaKit Pro
 *
 * @package MediaKit_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Register all meta boxes
 */
function mkp_register_meta_boxes() {
    // Speaking Topic Meta Box
    add_meta_box(
        'mkp_speaking_topic_details',
        __( 'Speaking Topic Details', 'mediakit-pro' ),
        'mkp_render_speaking_topic_meta_box',
        'speaking_topic',
        'normal',
        'high'
    );
    
    // Media Appearance Meta Box
    add_meta_box(
        'mkp_media_appearance_details',
        __( 'Media Appearance Details', 'mediakit-pro' ),
        'mkp_render_media_appearance_meta_box',
        'media_appearance',
        'normal',
        'high'
    );
    
    // Portfolio Item Meta Box
    add_meta_box(
        'mkp_portfolio_details',
        __( 'Portfolio Details', 'mediakit-pro' ),
        'mkp_render_portfolio_meta_box',
        'portfolio_item',
        'normal',
        'high'
    );
    
    // Testimonial Meta Box
    add_meta_box(
        'mkp_testimonial_details',
        __( 'Testimonial Details', 'mediakit-pro' ),
        'mkp_render_testimonial_meta_box',
        'testimonial',
        'normal',
        'high'
    );
    
    // Press Mention Meta Box
    add_meta_box(
        'mkp_press_mention_details',
        __( 'Press Mention Details', 'mediakit-pro' ),
        'mkp_render_press_mention_meta_box',
        'press_mention',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'mkp_register_meta_boxes' );

/**
 * Render Speaking Topic Meta Box
 */
function mkp_render_speaking_topic_meta_box( $post ) {
    wp_nonce_field( 'mkp_speaking_topic_nonce', 'mkp_speaking_topic_nonce' );
    
    $target_audience = get_post_meta( $post->ID, '_mkp_target_audience', true );
    $duration = get_post_meta( $post->ID, '_mkp_duration', true );
    $key_takeaways = get_post_meta( $post->ID, '_mkp_key_takeaways', true );
    
    if ( ! is_array( $key_takeaways ) ) {
        $key_takeaways = array();
    }
    ?>
    
    <div class="mkp-meta-box">
        <div class="mkp-field">
            <label for="mkp_target_audience"><?php esc_html_e( 'Target Audience', 'mediakit-pro' ); ?></label>
            <input type="text" id="mkp_target_audience" name="mkp_target_audience" value="<?php echo esc_attr( $target_audience ); ?>" class="large-text" />
            <p class="description"><?php esc_html_e( 'Who is this speaking topic best suited for?', 'mediakit-pro' ); ?></p>
        </div>
        
        <div class="mkp-field">
            <label for="mkp_duration"><?php esc_html_e( 'Typical Duration', 'mediakit-pro' ); ?></label>
            <select id="mkp_duration" name="mkp_duration">
                <option value=""><?php esc_html_e( 'Select Duration', 'mediakit-pro' ); ?></option>
                <option value="30min" <?php selected( $duration, '30min' ); ?>><?php esc_html_e( '30 minutes', 'mediakit-pro' ); ?></option>
                <option value="45min" <?php selected( $duration, '45min' ); ?>><?php esc_html_e( '45 minutes', 'mediakit-pro' ); ?></option>
                <option value="60min" <?php selected( $duration, '60min' ); ?>><?php esc_html_e( '60 minutes', 'mediakit-pro' ); ?></option>
                <option value="90min" <?php selected( $duration, '90min' ); ?>><?php esc_html_e( '90 minutes', 'mediakit-pro' ); ?></option>
                <option value="half-day" <?php selected( $duration, 'half-day' ); ?>><?php esc_html_e( 'Half Day Workshop', 'mediakit-pro' ); ?></option>
                <option value="full-day" <?php selected( $duration, 'full-day' ); ?>><?php esc_html_e( 'Full Day Workshop', 'mediakit-pro' ); ?></option>
            </select>
        </div>
        
        <div class="mkp-field mkp-repeater-field">
            <label><?php esc_html_e( 'Key Takeaways', 'mediakit-pro' ); ?></label>
            <div class="mkp-repeater" data-min="3" data-max="10">
                <div class="mkp-repeater-items">
                    <?php
                    if ( ! empty( $key_takeaways ) ) {
                        foreach ( $key_takeaways as $index => $takeaway ) {
                            ?>
                            <div class="mkp-repeater-item">
                                <input type="text" name="mkp_key_takeaways[]" value="<?php echo esc_attr( $takeaway ); ?>" class="large-text" />
                                <button type="button" class="button mkp-remove-item"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                            </div>
                            <?php
                        }
                    } else {
                        // Show 3 empty fields by default
                        for ( $i = 0; $i < 3; $i++ ) {
                            ?>
                            <div class="mkp-repeater-item">
                                <input type="text" name="mkp_key_takeaways[]" value="" class="large-text" />
                                <button type="button" class="button mkp-remove-item"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                            </div>
                            <?php
                        }
                    }
                    ?>
                </div>
                <button type="button" class="button mkp-add-item"><?php esc_html_e( 'Add Takeaway', 'mediakit-pro' ); ?></button>
            </div>
        </div>
    </div>
    <?php
}

/**
 * Render Media Appearance Meta Box
 */
function mkp_render_media_appearance_meta_box( $post ) {
    wp_nonce_field( 'mkp_media_appearance_nonce', 'mkp_media_appearance_nonce' );
    
    $appearance_date = get_post_meta( $post->ID, '_mkp_appearance_date', true );
    $outlet_name = get_post_meta( $post->ID, '_mkp_outlet_name', true );
    $media_embed = get_post_meta( $post->ID, '_mkp_media_embed', true );
    $external_link = get_post_meta( $post->ID, '_mkp_external_link', true );
    ?>
    
    <div class="mkp-meta-box">
        <div class="mkp-field">
            <label for="mkp_appearance_date"><?php esc_html_e( 'Appearance Date', 'mediakit-pro' ); ?></label>
            <input type="date" id="mkp_appearance_date" name="mkp_appearance_date" value="<?php echo esc_attr( $appearance_date ); ?>" />
        </div>
        
        <div class="mkp-field">
            <label for="mkp_outlet_name"><?php esc_html_e( 'Media Outlet Name', 'mediakit-pro' ); ?></label>
            <input type="text" id="mkp_outlet_name" name="mkp_outlet_name" value="<?php echo esc_attr( $outlet_name ); ?>" class="large-text" />
        </div>
        
        <div class="mkp-field">
            <label for="mkp_media_embed"><?php esc_html_e( 'Media Embed URL', 'mediakit-pro' ); ?></label>
            <input type="url" id="mkp_media_embed" name="mkp_media_embed" value="<?php echo esc_url( $media_embed ); ?>" class="large-text" />
            <p class="description"><?php esc_html_e( 'Paste the URL of the video or audio (YouTube, Vimeo, etc.)', 'mediakit-pro' ); ?></p>
        </div>
        
        <div class="mkp-field">
            <label for="mkp_external_link"><?php esc_html_e( 'External Link', 'mediakit-pro' ); ?></label>
            <input type="url" id="mkp_external_link" name="mkp_external_link" value="<?php echo esc_url( $external_link ); ?>" class="large-text" />
            <p class="description"><?php esc_html_e( 'Link to the original article or media', 'mediakit-pro' ); ?></p>
        </div>
    </div>
    <?php
}

/**
 * Render Portfolio Meta Box
 */
function mkp_render_portfolio_meta_box( $post ) {
    wp_nonce_field( 'mkp_portfolio_nonce', 'mkp_portfolio_nonce' );
    
    $project_gallery = get_post_meta( $post->ID, '_mkp_project_gallery', true );
    $project_video = get_post_meta( $post->ID, '_mkp_project_video', true );
    $project_date = get_post_meta( $post->ID, '_mkp_project_date', true );
    $client_name = get_post_meta( $post->ID, '_mkp_client_name', true );
    $project_url = get_post_meta( $post->ID, '_mkp_project_url', true );
    
    if ( ! is_array( $project_gallery ) ) {
        $project_gallery = array();
    }
    ?>
    
    <div class="mkp-meta-box">
        <div class="mkp-field mkp-gallery-field">
            <label><?php esc_html_e( 'Project Gallery', 'mediakit-pro' ); ?></label>
            <div class="mkp-gallery-container">
                <div class="mkp-gallery-images" data-gallery="project">
                    <?php
                    foreach ( $project_gallery as $image_id ) {
                        $image_url = wp_get_attachment_image_url( $image_id, 'thumbnail' );
                        if ( $image_url ) {
                            ?>
                            <div class="mkp-gallery-item" data-id="<?php echo esc_attr( $image_id ); ?>">
                                <img src="<?php echo esc_url( $image_url ); ?>" alt="" />
                                <button type="button" class="mkp-remove-image">&times;</button>
                                <input type="hidden" name="mkp_project_gallery[]" value="<?php echo esc_attr( $image_id ); ?>" />
                            </div>
                            <?php
                        }
                    }
                    ?>
                </div>
                <button type="button" class="button mkp-add-gallery-images"><?php esc_html_e( 'Add Images', 'mediakit-pro' ); ?></button>
            </div>
            <p class="description"><?php esc_html_e( 'Upload multiple images for this project', 'mediakit-pro' ); ?></p>
        </div>
        
        <div class="mkp-field">
            <label for="mkp_project_video"><?php esc_html_e( 'Project Video URL', 'mediakit-pro' ); ?></label>
            <input type="url" id="mkp_project_video" name="mkp_project_video" value="<?php echo esc_url( $project_video ); ?>" class="large-text" />
        </div>
        
        <div class="mkp-field">
            <label for="mkp_project_date"><?php esc_html_e( 'Project Date', 'mediakit-pro' ); ?></label>
            <input type="date" id="mkp_project_date" name="mkp_project_date" value="<?php echo esc_attr( $project_date ); ?>" />
        </div>
        
        <div class="mkp-field">
            <label for="mkp_client_name"><?php esc_html_e( 'Client Name', 'mediakit-pro' ); ?></label>
            <input type="text" id="mkp_client_name" name="mkp_client_name" value="<?php echo esc_attr( $client_name ); ?>" class="large-text" />
        </div>
        
        <div class="mkp-field">
            <label for="mkp_project_url"><?php esc_html_e( 'Project URL', 'mediakit-pro' ); ?></label>
            <input type="url" id="mkp_project_url" name="mkp_project_url" value="<?php echo esc_url( $project_url ); ?>" class="large-text" />
        </div>
    </div>
    <?php
}

/**
 * Render Testimonial Meta Box
 */
function mkp_render_testimonial_meta_box( $post ) {
    wp_nonce_field( 'mkp_testimonial_nonce', 'mkp_testimonial_nonce' );
    
    $testimonial_text = get_post_meta( $post->ID, '_mkp_testimonial_text', true );
    $author_name = get_post_meta( $post->ID, '_mkp_author_name', true );
    $author_title = get_post_meta( $post->ID, '_mkp_author_title', true );
    $author_company = get_post_meta( $post->ID, '_mkp_author_company', true );
    $author_photo = get_post_meta( $post->ID, '_mkp_author_photo', true );
    $rating = get_post_meta( $post->ID, '_mkp_rating', true );
    ?>
    
    <div class="mkp-meta-box">
        <div class="mkp-field">
            <label for="mkp_testimonial_text"><?php esc_html_e( 'Testimonial Quote', 'mediakit-pro' ); ?> <span class="required">*</span></label>
            <textarea id="mkp_testimonial_text" name="mkp_testimonial_text" rows="4" class="large-text" required><?php echo esc_textarea( $testimonial_text ); ?></textarea>
        </div>
        
        <div class="mkp-field">
            <label for="mkp_author_name"><?php esc_html_e( 'Author Name', 'mediakit-pro' ); ?> <span class="required">*</span></label>
            <input type="text" id="mkp_author_name" name="mkp_author_name" value="<?php echo esc_attr( $author_name ); ?>" class="large-text" required />
        </div>
        
        <div class="mkp-field">
            <label for="mkp_author_title"><?php esc_html_e( 'Author Title', 'mediakit-pro' ); ?></label>
            <input type="text" id="mkp_author_title" name="mkp_author_title" value="<?php echo esc_attr( $author_title ); ?>" class="large-text" />
        </div>
        
        <div class="mkp-field">
            <label for="mkp_author_company"><?php esc_html_e( 'Company/Organization', 'mediakit-pro' ); ?></label>
            <input type="text" id="mkp_author_company" name="mkp_author_company" value="<?php echo esc_attr( $author_company ); ?>" class="large-text" />
        </div>
        
        <div class="mkp-field mkp-image-field">
            <label><?php esc_html_e( 'Author Photo', 'mediakit-pro' ); ?></label>
            <div class="mkp-image-container">
                <?php if ( $author_photo ) : ?>
                    <?php $image_url = wp_get_attachment_image_url( $author_photo, 'thumbnail' ); ?>
                    <div class="mkp-image-preview" style="display: <?php echo $image_url ? 'block' : 'none'; ?>;">
                        <img src="<?php echo esc_url( $image_url ); ?>" alt="" />
                        <button type="button" class="button mkp-remove-image"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                    </div>
                <?php else : ?>
                    <div class="mkp-image-preview" style="display: none;">
                        <img src="" alt="" />
                        <button type="button" class="button mkp-remove-image"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                    </div>
                <?php endif; ?>
                <input type="hidden" id="mkp_author_photo" name="mkp_author_photo" value="<?php echo esc_attr( $author_photo ); ?>" />
                <button type="button" class="button mkp-add-image"><?php esc_html_e( 'Select Image', 'mediakit-pro' ); ?></button>
            </div>
        </div>
        
        <div class="mkp-field">
            <label for="mkp_rating"><?php esc_html_e( 'Rating', 'mediakit-pro' ); ?></label>
            <input type="number" id="mkp_rating" name="mkp_rating" value="<?php echo esc_attr( $rating ?: 5 ); ?>" min="1" max="5" />
        </div>
    </div>
    <?php
}

/**
 * Render Press Mention Meta Box
 */
function mkp_render_press_mention_meta_box( $post ) {
    wp_nonce_field( 'mkp_press_mention_nonce', 'mkp_press_mention_nonce' );
    
    $publication_name = get_post_meta( $post->ID, '_mkp_publication_name', true );
    $publication_date = get_post_meta( $post->ID, '_mkp_publication_date', true );
    $article_title = get_post_meta( $post->ID, '_mkp_article_title', true );
    $article_link = get_post_meta( $post->ID, '_mkp_article_link', true );
    $pull_quote = get_post_meta( $post->ID, '_mkp_pull_quote', true );
    $publication_logo = get_post_meta( $post->ID, '_mkp_publication_logo', true );
    ?>
    
    <div class="mkp-meta-box">
        <div class="mkp-field">
            <label for="mkp_publication_name"><?php esc_html_e( 'Publication Name', 'mediakit-pro' ); ?> <span class="required">*</span></label>
            <input type="text" id="mkp_publication_name" name="mkp_publication_name" value="<?php echo esc_attr( $publication_name ); ?>" class="large-text" required />
        </div>
        
        <div class="mkp-field">
            <label for="mkp_publication_date"><?php esc_html_e( 'Publication Date', 'mediakit-pro' ); ?></label>
            <input type="date" id="mkp_publication_date" name="mkp_publication_date" value="<?php echo esc_attr( $publication_date ); ?>" />
        </div>
        
        <div class="mkp-field">
            <label for="mkp_article_title"><?php esc_html_e( 'Article Title', 'mediakit-pro' ); ?></label>
            <input type="text" id="mkp_article_title" name="mkp_article_title" value="<?php echo esc_attr( $article_title ); ?>" class="large-text" />
        </div>
        
        <div class="mkp-field">
            <label for="mkp_article_link"><?php esc_html_e( 'Article Link', 'mediakit-pro' ); ?></label>
            <input type="url" id="mkp_article_link" name="mkp_article_link" value="<?php echo esc_url( $article_link ); ?>" class="large-text" />
        </div>
        
        <div class="mkp-field">
            <label for="mkp_pull_quote"><?php esc_html_e( 'Pull Quote', 'mediakit-pro' ); ?></label>
            <textarea id="mkp_pull_quote" name="mkp_pull_quote" rows="3" class="large-text"><?php echo esc_textarea( $pull_quote ); ?></textarea>
            <p class="description"><?php esc_html_e( 'A key quote from the article', 'mediakit-pro' ); ?></p>
        </div>
        
        <div class="mkp-field mkp-image-field">
            <label><?php esc_html_e( 'Publication Logo', 'mediakit-pro' ); ?></label>
            <div class="mkp-image-container">
                <?php if ( $publication_logo ) : ?>
                    <?php $image_url = wp_get_attachment_image_url( $publication_logo, 'medium' ); ?>
                    <div class="mkp-image-preview" style="display: <?php echo $image_url ? 'block' : 'none'; ?>;">
                        <img src="<?php echo esc_url( $image_url ); ?>" alt="" />
                        <button type="button" class="button mkp-remove-image"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                    </div>
                <?php else : ?>
                    <div class="mkp-image-preview" style="display: none;">
                        <img src="" alt="" />
                        <button type="button" class="button mkp-remove-image"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                    </div>
                <?php endif; ?>
                <input type="hidden" id="mkp_publication_logo" name="mkp_publication_logo" value="<?php echo esc_attr( $publication_logo ); ?>" />
                <button type="button" class="button mkp-add-image"><?php esc_html_e( 'Select Logo', 'mediakit-pro' ); ?></button>
            </div>
        </div>
    </div>
    <?php
}

/**
 * Save meta box data
 */
function mkp_save_meta_box_data( $post_id ) {
    // Check if our nonce is set and verify it
    $nonce_actions = array(
        'speaking_topic' => 'mkp_speaking_topic_nonce',
        'media_appearance' => 'mkp_media_appearance_nonce',
        'portfolio_item' => 'mkp_portfolio_nonce',
        'testimonial' => 'mkp_testimonial_nonce',
        'press_mention' => 'mkp_press_mention_nonce',
    );
    
    $post_type = get_post_type( $post_id );
    
    if ( ! isset( $nonce_actions[ $post_type ] ) ) {
        return;
    }
    
    $nonce_name = $nonce_actions[ $post_type ];
    
    if ( ! isset( $_POST[ $nonce_name ] ) || ! wp_verify_nonce( $_POST[ $nonce_name ], $nonce_name ) ) {
        return;
    }
    
    // Check if the current user has permission to edit the post
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }
    
    // Save Speaking Topic fields
    if ( $post_type === 'speaking_topic' ) {
        if ( isset( $_POST['mkp_target_audience'] ) ) {
            update_post_meta( $post_id, '_mkp_target_audience', sanitize_text_field( $_POST['mkp_target_audience'] ) );
        }
        
        if ( isset( $_POST['mkp_duration'] ) ) {
            update_post_meta( $post_id, '_mkp_duration', sanitize_text_field( $_POST['mkp_duration'] ) );
        }
        
        if ( isset( $_POST['mkp_key_takeaways'] ) && is_array( $_POST['mkp_key_takeaways'] ) ) {
            $takeaways = array_filter( array_map( 'sanitize_text_field', $_POST['mkp_key_takeaways'] ) );
            update_post_meta( $post_id, '_mkp_key_takeaways', $takeaways );
        }
    }
    
    // Save Media Appearance fields
    elseif ( $post_type === 'media_appearance' ) {
        if ( isset( $_POST['mkp_appearance_date'] ) ) {
            update_post_meta( $post_id, '_mkp_appearance_date', sanitize_text_field( $_POST['mkp_appearance_date'] ) );
        }
        
        if ( isset( $_POST['mkp_outlet_name'] ) ) {
            update_post_meta( $post_id, '_mkp_outlet_name', sanitize_text_field( $_POST['mkp_outlet_name'] ) );
        }
        
        if ( isset( $_POST['mkp_media_embed'] ) ) {
            update_post_meta( $post_id, '_mkp_media_embed', esc_url_raw( $_POST['mkp_media_embed'] ) );
        }
        
        if ( isset( $_POST['mkp_external_link'] ) ) {
            update_post_meta( $post_id, '_mkp_external_link', esc_url_raw( $_POST['mkp_external_link'] ) );
        }
    }
    
    // Save Portfolio fields
    elseif ( $post_type === 'portfolio_item' ) {
        if ( isset( $_POST['mkp_project_gallery'] ) && is_array( $_POST['mkp_project_gallery'] ) ) {
            $gallery = array_map( 'intval', $_POST['mkp_project_gallery'] );
            update_post_meta( $post_id, '_mkp_project_gallery', $gallery );
        } else {
            delete_post_meta( $post_id, '_mkp_project_gallery' );
        }
        
        if ( isset( $_POST['mkp_project_video'] ) ) {
            update_post_meta( $post_id, '_mkp_project_video', esc_url_raw( $_POST['mkp_project_video'] ) );
        }
        
        if ( isset( $_POST['mkp_project_date'] ) ) {
            update_post_meta( $post_id, '_mkp_project_date', sanitize_text_field( $_POST['mkp_project_date'] ) );
        }
        
        if ( isset( $_POST['mkp_client_name'] ) ) {
            update_post_meta( $post_id, '_mkp_client_name', sanitize_text_field( $_POST['mkp_client_name'] ) );
        }
        
        if ( isset( $_POST['mkp_project_url'] ) ) {
            update_post_meta( $post_id, '_mkp_project_url', esc_url_raw( $_POST['mkp_project_url'] ) );
        }
    }
    
    // Save Testimonial fields
    elseif ( $post_type === 'testimonial' ) {
        if ( isset( $_POST['mkp_testimonial_text'] ) ) {
            update_post_meta( $post_id, '_mkp_testimonial_text', sanitize_textarea_field( $_POST['mkp_testimonial_text'] ) );
        }
        
        if ( isset( $_POST['mkp_author_name'] ) ) {
            update_post_meta( $post_id, '_mkp_author_name', sanitize_text_field( $_POST['mkp_author_name'] ) );
        }
        
        if ( isset( $_POST['mkp_author_title'] ) ) {
            update_post_meta( $post_id, '_mkp_author_title', sanitize_text_field( $_POST['mkp_author_title'] ) );
        }
        
        if ( isset( $_POST['mkp_author_company'] ) ) {
            update_post_meta( $post_id, '_mkp_author_company', sanitize_text_field( $_POST['mkp_author_company'] ) );
        }
        
        if ( isset( $_POST['mkp_author_photo'] ) ) {
            update_post_meta( $post_id, '_mkp_author_photo', intval( $_POST['mkp_author_photo'] ) );
        }
        
        if ( isset( $_POST['mkp_rating'] ) ) {
            $rating = intval( $_POST['mkp_rating'] );
            $rating = max( 1, min( 5, $rating ) ); // Ensure between 1 and 5
            update_post_meta( $post_id, '_mkp_rating', $rating );
        }
    }
    
    // Save Press Mention fields
    elseif ( $post_type === 'press_mention' ) {
        if ( isset( $_POST['mkp_publication_name'] ) ) {
            update_post_meta( $post_id, '_mkp_publication_name', sanitize_text_field( $_POST['mkp_publication_name'] ) );
        }
        
        if ( isset( $_POST['mkp_publication_date'] ) ) {
            update_post_meta( $post_id, '_mkp_publication_date', sanitize_text_field( $_POST['mkp_publication_date'] ) );
        }
        
        if ( isset( $_POST['mkp_article_title'] ) ) {
            update_post_meta( $post_id, '_mkp_article_title', sanitize_text_field( $_POST['mkp_article_title'] ) );
        }
        
        if ( isset( $_POST['mkp_article_link'] ) ) {
            update_post_meta( $post_id, '_mkp_article_link', esc_url_raw( $_POST['mkp_article_link'] ) );
        }
        
        if ( isset( $_POST['mkp_pull_quote'] ) ) {
            update_post_meta( $post_id, '_mkp_pull_quote', sanitize_textarea_field( $_POST['mkp_pull_quote'] ) );
        }
        
        if ( isset( $_POST['mkp_publication_logo'] ) ) {
            update_post_meta( $post_id, '_mkp_publication_logo', intval( $_POST['mkp_publication_logo'] ) );
        }
    }
}
add_action( 'save_post', 'mkp_save_meta_box_data' );

/**
 * Enqueue admin scripts and styles for meta boxes
 */
function mkp_enqueue_meta_box_assets( $hook ) {
    global $post_type;
    
    if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ) ) ) {
        return;
    }
    
    $allowed_post_types = array( 'speaking_topic', 'media_appearance', 'portfolio_item', 'testimonial', 'press_mention' );
    
    if ( ! in_array( $post_type, $allowed_post_types ) ) {
        return;
    }
    
    // Enqueue WordPress media scripts
    wp_enqueue_media();
    
    // Enqueue custom meta box script
    wp_enqueue_script(
        'mkp-meta-boxes',
        get_template_directory_uri() . '/assets/js/meta-boxes.js',
        array( 'jquery' ),
        MKP_THEME_VERSION,
        true
    );
    
    // Localize script
    wp_localize_script( 'mkp-meta-boxes', 'mkpMetaBox', array(
        'selectImage' => __( 'Select Image', 'mediakit-pro' ),
        'selectImages' => __( 'Select Images', 'mediakit-pro' ),
        'useImage' => __( 'Use this image', 'mediakit-pro' ),
        'useImages' => __( 'Use these images', 'mediakit-pro' ),
    ) );
    
    // Enqueue custom meta box styles
    wp_enqueue_style(
        'mkp-meta-boxes',
        get_template_directory_uri() . '/assets/css/meta-boxes.css',
        array(),
        MKP_THEME_VERSION
    );
}
add_action( 'admin_enqueue_scripts', 'mkp_enqueue_meta_box_assets' );