<?php
/**
 * Options Pages for MediaKit Pro
 *
 * @package MediaKit_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Register options pages
 */
function mkp_add_options_pages() {
    // Media Kit Settings
    add_submenu_page(
        'mediakit-pro',
        __( 'Media Kit Settings', 'mediakit-pro' ),
        __( 'Media Kit Settings', 'mediakit-pro' ),
        'manage_options',
        'media-kit-settings',
        'mkp_render_media_kit_settings_page'
    );
    
    // Interview Resources
    add_submenu_page(
        'mediakit-pro',
        __( 'Interview Resources', 'mediakit-pro' ),
        __( 'Interview Resources', 'mediakit-pro' ),
        'manage_options',
        'interview-resources',
        'mkp_render_interview_resources_page'
    );
}
add_action( 'admin_menu', 'mkp_add_options_pages', 20 );

/**
 * Register settings
 */
function mkp_register_settings() {
    // Media Kit Settings
    register_setting( 'mkp_media_kit_settings', 'mkp_headshots_gallery' );
    register_setting( 'mkp_media_kit_settings', 'mkp_bio_short' );
    register_setting( 'mkp_media_kit_settings', 'mkp_bio_long' );
    register_setting( 'mkp_media_kit_settings', 'mkp_key_achievements' );
    register_setting( 'mkp_media_kit_settings', 'mkp_languages_spoken' );
    register_setting( 'mkp_media_kit_settings', 'mkp_available_for' );
    register_setting( 'mkp_media_kit_settings', 'mkp_speaking_stats' );
    register_setting( 'mkp_media_kit_settings', 'mkp_media_logos' );
    
    // Interview Resources
    register_setting( 'mkp_interview_resources', 'mkp_suggested_questions' );
    register_setting( 'mkp_interview_resources', 'mkp_one_sheet_pdf' );
    register_setting( 'mkp_interview_resources', 'mkp_broll_links' );
    register_setting( 'mkp_interview_resources', 'mkp_brand_guidelines_pdf' );
}
add_action( 'admin_init', 'mkp_register_settings' );

/**
 * Render Media Kit Settings Page
 */
function mkp_render_media_kit_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    
    // Save message
    if ( isset( $_GET['settings-updated'] ) ) {
        add_settings_error( 'mkp_messages', 'mkp_message', __( 'Settings saved.', 'mediakit-pro' ), 'updated' );
    }
    
    settings_errors( 'mkp_messages' );
    ?>
    
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        
        <form method="post" action="options.php" enctype="multipart/form-data">
            <?php settings_fields( 'mkp_media_kit_settings' ); ?>
            
            <div class="mkp-options-page">
                <!-- Professional Headshots -->
                <div class="mkp-option-section">
                    <h2><?php esc_html_e( 'Professional Headshots', 'mediakit-pro' ); ?></h2>
                    <?php mkp_render_gallery_field( 'mkp_headshots_gallery', get_option( 'mkp_headshots_gallery' ) ); ?>
                    <p class="description"><?php esc_html_e( 'Upload high-resolution headshots for media use.', 'mediakit-pro' ); ?></p>
                </div>
                
                <!-- Bio Versions -->
                <div class="mkp-option-section">
                    <h2><?php esc_html_e( 'Professional Bio', 'mediakit-pro' ); ?></h2>
                    
                    <div class="mkp-field">
                        <label for="mkp_bio_short"><?php esc_html_e( 'Short Bio (50-100 words)', 'mediakit-pro' ); ?></label>
                        <textarea id="mkp_bio_short" name="mkp_bio_short" rows="3" class="large-text"><?php echo esc_textarea( get_option( 'mkp_bio_short' ) ); ?></textarea>
                    </div>
                    
                    <div class="mkp-field">
                        <label for="mkp_bio_long"><?php esc_html_e( 'Long Bio (200-500 words)', 'mediakit-pro' ); ?></label>
                        <?php
                        wp_editor( get_option( 'mkp_bio_long' ), 'mkp_bio_long', array(
                            'textarea_name' => 'mkp_bio_long',
                            'textarea_rows' => 10,
                            'media_buttons' => false,
                            'teeny' => true,
                        ) );
                        ?>
                    </div>
                </div>
                
                <!-- Key Achievements -->
                <div class="mkp-option-section">
                    <h2><?php esc_html_e( 'Key Achievements', 'mediakit-pro' ); ?></h2>
                    <?php mkp_render_repeater_field( 'mkp_key_achievements', get_option( 'mkp_key_achievements' ), 'achievement' ); ?>
                </div>
                
                <!-- Languages -->
                <div class="mkp-option-section">
                    <h2><?php esc_html_e( 'Languages Spoken', 'mediakit-pro' ); ?></h2>
                    <input type="text" name="mkp_languages_spoken" value="<?php echo esc_attr( get_option( 'mkp_languages_spoken' ) ); ?>" class="large-text" />
                    <p class="description"><?php esc_html_e( 'Comma-separated list of languages', 'mediakit-pro' ); ?></p>
                </div>
                
                <!-- Available For -->
                <div class="mkp-option-section">
                    <h2><?php esc_html_e( 'Available For', 'mediakit-pro' ); ?></h2>
                    <?php
                    $available_for = get_option( 'mkp_available_for', array() );
                    if ( ! is_array( $available_for ) ) {
                        $available_for = array();
                    }
                    
                    $options = array(
                        'speaking' => __( 'Speaking Engagements', 'mediakit-pro' ),
                        'workshops' => __( 'Workshops', 'mediakit-pro' ),
                        'consulting' => __( 'Consulting', 'mediakit-pro' ),
                        'media' => __( 'Media Appearances', 'mediakit-pro' ),
                        'podcasts' => __( 'Podcast Interviews', 'mediakit-pro' ),
                        'writing' => __( 'Guest Writing', 'mediakit-pro' ),
                    );
                    
                    foreach ( $options as $value => $label ) :
                        ?>
                        <label>
                            <input type="checkbox" name="mkp_available_for[]" value="<?php echo esc_attr( $value ); ?>" <?php checked( in_array( $value, $available_for ) ); ?> />
                            <?php echo esc_html( $label ); ?>
                        </label><br>
                        <?php
                    endforeach;
                    ?>
                </div>
                
                <!-- Speaking Stats -->
                <div class="mkp-option-section">
                    <h2><?php esc_html_e( 'Speaking Statistics', 'mediakit-pro' ); ?></h2>
                    <?php mkp_render_stats_repeater( 'mkp_speaking_stats', get_option( 'mkp_speaking_stats' ) ); ?>
                </div>
                
                <!-- Media Logos -->
                <div class="mkp-option-section">
                    <h2><?php esc_html_e( 'Media Logos', 'mediakit-pro' ); ?></h2>
                    <?php mkp_render_media_logos_repeater( 'mkp_media_logos', get_option( 'mkp_media_logos' ) ); ?>
                </div>
            </div>
            
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

/**
 * Render Interview Resources Page
 */
function mkp_render_interview_resources_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    
    // Save message
    if ( isset( $_GET['settings-updated'] ) ) {
        add_settings_error( 'mkp_messages', 'mkp_message', __( 'Settings saved.', 'mediakit-pro' ), 'updated' );
    }
    
    settings_errors( 'mkp_messages' );
    ?>
    
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        
        <form method="post" action="options.php">
            <?php settings_fields( 'mkp_interview_resources' ); ?>
            
            <div class="mkp-options-page">
                <!-- Suggested Questions -->
                <div class="mkp-option-section">
                    <h2><?php esc_html_e( 'Suggested Interview Questions', 'mediakit-pro' ); ?></h2>
                    <?php mkp_render_questions_repeater( 'mkp_suggested_questions', get_option( 'mkp_suggested_questions' ) ); ?>
                </div>
                
                <!-- One Sheet PDF -->
                <div class="mkp-option-section">
                    <h2><?php esc_html_e( 'Speaker One-Sheet', 'mediakit-pro' ); ?></h2>
                    <?php mkp_render_file_field( 'mkp_one_sheet_pdf', get_option( 'mkp_one_sheet_pdf' ), 'PDF' ); ?>
                    <p class="description"><?php esc_html_e( 'Upload your speaker one-sheet PDF', 'mediakit-pro' ); ?></p>
                </div>
                
                <!-- B-Roll Links -->
                <div class="mkp-option-section">
                    <h2><?php esc_html_e( 'B-Roll Footage Links', 'mediakit-pro' ); ?></h2>
                    <?php mkp_render_links_repeater( 'mkp_broll_links', get_option( 'mkp_broll_links' ) ); ?>
                </div>
                
                <!-- Brand Guidelines -->
                <div class="mkp-option-section">
                    <h2><?php esc_html_e( 'Brand Guidelines', 'mediakit-pro' ); ?></h2>
                    <?php mkp_render_file_field( 'mkp_brand_guidelines_pdf', get_option( 'mkp_brand_guidelines_pdf' ), 'PDF' ); ?>
                    <p class="description"><?php esc_html_e( 'Upload your brand guidelines PDF', 'mediakit-pro' ); ?></p>
                </div>
            </div>
            
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

/**
 * Render gallery field
 */
function mkp_render_gallery_field( $name, $value ) {
    if ( ! is_array( $value ) ) {
        $value = array();
    }
    ?>
    <div class="mkp-field mkp-gallery-field">
        <div class="mkp-gallery-container">
            <div class="mkp-gallery-images" data-gallery="<?php echo esc_attr( $name ); ?>">
                <?php
                foreach ( $value as $image_id ) {
                    $image_url = wp_get_attachment_image_url( $image_id, 'thumbnail' );
                    if ( $image_url ) {
                        ?>
                        <div class="mkp-gallery-item" data-id="<?php echo esc_attr( $image_id ); ?>">
                            <img src="<?php echo esc_url( $image_url ); ?>" alt="" />
                            <button type="button" class="mkp-remove-image">&times;</button>
                            <input type="hidden" name="<?php echo esc_attr( $name ); ?>[]" value="<?php echo esc_attr( $image_id ); ?>" />
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
            <button type="button" class="button mkp-add-gallery-images"><?php esc_html_e( 'Add Images', 'mediakit-pro' ); ?></button>
        </div>
    </div>
    <?php
}

/**
 * Render repeater field
 */
function mkp_render_repeater_field( $name, $value, $field_name = 'item' ) {
    if ( ! is_array( $value ) ) {
        $value = array();
    }
    ?>
    <div class="mkp-field mkp-repeater-field">
        <div class="mkp-repeater" data-field-name="<?php echo esc_attr( $name ); ?>">
            <div class="mkp-repeater-items">
                <?php
                if ( ! empty( $value ) ) {
                    foreach ( $value as $index => $item ) {
                        ?>
                        <div class="mkp-repeater-item">
                            <input type="text" name="<?php echo esc_attr( $name ); ?>[]" value="<?php echo esc_attr( $item ); ?>" class="large-text" />
                            <button type="button" class="button mkp-remove-item"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                        </div>
                        <?php
                    }
                } else {
                    ?>
                    <div class="mkp-repeater-item">
                        <input type="text" name="<?php echo esc_attr( $name ); ?>[]" value="" class="large-text" />
                        <button type="button" class="button mkp-remove-item"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                    </div>
                    <?php
                }
                ?>
            </div>
            <button type="button" class="button mkp-add-item"><?php esc_html_e( 'Add Item', 'mediakit-pro' ); ?></button>
        </div>
    </div>
    <?php
}

/**
 * Render stats repeater
 */
function mkp_render_stats_repeater( $name, $value ) {
    if ( ! is_array( $value ) ) {
        $value = array();
    }
    ?>
    <div class="mkp-field mkp-repeater-field">
        <div class="mkp-repeater mkp-stats-repeater" data-field-name="<?php echo esc_attr( $name ); ?>">
            <div class="mkp-repeater-items">
                <?php
                if ( ! empty( $value ) ) {
                    foreach ( $value as $index => $stat ) {
                        ?>
                        <div class="mkp-repeater-item mkp-stats-item">
                            <input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][number]" value="<?php echo esc_attr( $stat['number'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Number', 'mediakit-pro' ); ?>" />
                            <input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][label]" value="<?php echo esc_attr( $stat['label'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Label', 'mediakit-pro' ); ?>" class="regular-text" />
                            <button type="button" class="button mkp-remove-item"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                        </div>
                        <?php
                    }
                } else {
                    ?>
                    <div class="mkp-repeater-item mkp-stats-item">
                        <input type="text" name="<?php echo esc_attr( $name ); ?>[0][number]" value="" placeholder="<?php esc_attr_e( 'Number', 'mediakit-pro' ); ?>" />
                        <input type="text" name="<?php echo esc_attr( $name ); ?>[0][label]" value="" placeholder="<?php esc_attr_e( 'Label', 'mediakit-pro' ); ?>" class="regular-text" />
                        <button type="button" class="button mkp-remove-item"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                    </div>
                    <?php
                }
                ?>
            </div>
            <button type="button" class="button mkp-add-stats-item"><?php esc_html_e( 'Add Stat', 'mediakit-pro' ); ?></button>
        </div>
    </div>
    <?php
}

/**
 * Render media logos repeater
 */
function mkp_render_media_logos_repeater( $name, $value ) {
    if ( ! is_array( $value ) ) {
        $value = array();
    }
    ?>
    <div class="mkp-field mkp-repeater-field">
        <div class="mkp-repeater mkp-media-logos-repeater" data-field-name="<?php echo esc_attr( $name ); ?>">
            <div class="mkp-repeater-items">
                <?php
                if ( ! empty( $value ) ) {
                    foreach ( $value as $index => $logo ) {
                        $logo_url = wp_get_attachment_image_url( $logo['logo'] ?? 0, 'thumbnail' );
                        ?>
                        <div class="mkp-repeater-item mkp-media-logo-item">
                            <div class="mkp-logo-preview">
                                <?php if ( $logo_url ) : ?>
                                    <img src="<?php echo esc_url( $logo_url ); ?>" alt="" />
                                <?php else : ?>
                                    <span><?php esc_html_e( 'No logo', 'mediakit-pro' ); ?></span>
                                <?php endif; ?>
                            </div>
                            <input type="hidden" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][logo]" value="<?php echo esc_attr( $logo['logo'] ?? '' ); ?>" class="mkp-logo-id" />
                            <button type="button" class="button mkp-select-logo"><?php esc_html_e( 'Select Logo', 'mediakit-pro' ); ?></button>
                            <input type="url" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][link]" value="<?php echo esc_url( $logo['link'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Link (optional)', 'mediakit-pro' ); ?>" />
                            <button type="button" class="button mkp-remove-item"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
            <button type="button" class="button mkp-add-logo-item"><?php esc_html_e( 'Add Logo', 'mediakit-pro' ); ?></button>
        </div>
    </div>
    <?php
}

/**
 * Render questions repeater
 */
function mkp_render_questions_repeater( $name, $value ) {
    if ( ! is_array( $value ) ) {
        $value = array();
    }
    ?>
    <div class="mkp-field mkp-repeater-field">
        <div class="mkp-repeater" data-field-name="<?php echo esc_attr( $name ); ?>">
            <div class="mkp-repeater-items">
                <?php
                if ( ! empty( $value ) ) {
                    foreach ( $value as $index => $question ) {
                        ?>
                        <div class="mkp-repeater-item">
                            <textarea name="<?php echo esc_attr( $name ); ?>[]" rows="2" class="large-text"><?php echo esc_textarea( $question ); ?></textarea>
                            <button type="button" class="button mkp-remove-item"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                        </div>
                        <?php
                    }
                } else {
                    // Show 3 empty fields by default
                    for ( $i = 0; $i < 3; $i++ ) {
                        ?>
                        <div class="mkp-repeater-item">
                            <textarea name="<?php echo esc_attr( $name ); ?>[]" rows="2" class="large-text"></textarea>
                            <button type="button" class="button mkp-remove-item"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
            <button type="button" class="button mkp-add-item"><?php esc_html_e( 'Add Question', 'mediakit-pro' ); ?></button>
        </div>
    </div>
    <?php
}

/**
 * Render links repeater
 */
function mkp_render_links_repeater( $name, $value ) {
    if ( ! is_array( $value ) ) {
        $value = array();
    }
    ?>
    <div class="mkp-field mkp-repeater-field">
        <div class="mkp-repeater mkp-links-repeater" data-field-name="<?php echo esc_attr( $name ); ?>">
            <div class="mkp-repeater-items">
                <?php
                if ( ! empty( $value ) ) {
                    foreach ( $value as $index => $link ) {
                        ?>
                        <div class="mkp-repeater-item mkp-link-item">
                            <input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][title]" value="<?php echo esc_attr( $link['title'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Title', 'mediakit-pro' ); ?>" />
                            <input type="url" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][link]" value="<?php echo esc_url( $link['link'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'URL', 'mediakit-pro' ); ?>" class="regular-text" />
                            <button type="button" class="button mkp-remove-item"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                        </div>
                        <?php
                    }
                } else {
                    ?>
                    <div class="mkp-repeater-item mkp-link-item">
                        <input type="text" name="<?php echo esc_attr( $name ); ?>[0][title]" value="" placeholder="<?php esc_attr_e( 'Title', 'mediakit-pro' ); ?>" />
                        <input type="url" name="<?php echo esc_attr( $name ); ?>[0][link]" value="" placeholder="<?php esc_attr_e( 'URL', 'mediakit-pro' ); ?>" class="regular-text" />
                        <button type="button" class="button mkp-remove-item"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
                    </div>
                    <?php
                }
                ?>
            </div>
            <button type="button" class="button mkp-add-link-item"><?php esc_html_e( 'Add Link', 'mediakit-pro' ); ?></button>
        </div>
    </div>
    <?php
}

/**
 * Render file field
 */
function mkp_render_file_field( $name, $value, $type = 'File' ) {
    $file_url = '';
    $file_name = '';
    
    if ( $value ) {
        $file_url = wp_get_attachment_url( $value );
        $file_name = basename( get_attached_file( $value ) );
    }
    ?>
    <div class="mkp-field mkp-file-field">
        <div class="mkp-file-container">
            <div class="mkp-file-preview" style="display: <?php echo $file_name ? 'block' : 'none'; ?>;">
                <span class="mkp-file-name"><?php echo esc_html( $file_name ); ?></span>
                <button type="button" class="button mkp-remove-file"><?php esc_html_e( 'Remove', 'mediakit-pro' ); ?></button>
            </div>
            <input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" />
            <button type="button" class="button mkp-add-file" data-type="<?php echo esc_attr( strtolower( $type ) ); ?>">
                <?php printf( esc_html__( 'Select %s', 'mediakit-pro' ), $type ); ?>
            </button>
        </div>
    </div>
    <?php
}

/**
 * Enqueue options page scripts
 */
function mkp_enqueue_options_scripts( $hook ) {
    if ( ! in_array( $hook, array( 'mediakit-pro_page_media-kit-settings', 'mediakit-pro_page_interview-resources' ) ) ) {
        return;
    }
    
    wp_enqueue_media();
    wp_enqueue_script( 'mkp-options-pages', get_template_directory_uri() . '/assets/js/options-pages.js', array( 'jquery' ), MKP_THEME_VERSION, true );
    wp_enqueue_style( 'mkp-meta-boxes', get_template_directory_uri() . '/assets/css/meta-boxes.css', array(), MKP_THEME_VERSION );
}
add_action( 'admin_enqueue_scripts', 'mkp_enqueue_options_scripts' );