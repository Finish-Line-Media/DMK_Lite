<?php
/**
 * Admin customizations and functions
 *
 * @package MediaKit_Pro
 */

/**
 * Customize admin dashboard
 */
function mkp_custom_dashboard_widgets() {
    // Remove default dashboard widgets
    remove_meta_box( 'dashboard_primary', 'dashboard', 'side' );
    remove_meta_box( 'dashboard_secondary', 'dashboard', 'side' );
    
    // Add custom dashboard widget
    wp_add_dashboard_widget(
        'mkp_dashboard_widget',
        __( 'Media Kit Overview', 'mediakit-pro' ),
        'mkp_dashboard_widget_display'
    );
}
add_action( 'wp_dashboard_setup', 'mkp_custom_dashboard_widgets' );

/**
 * Display custom dashboard widget
 */
function mkp_dashboard_widget_display() {
    // Get statistics
    $speaking_topics = wp_count_posts( 'speaking_topic' );
    $media_appearances = wp_count_posts( 'media_appearance' );
    $portfolio_items = wp_count_posts( 'portfolio_item' );
    $testimonials = wp_count_posts( 'testimonial' );
    $press_mentions = wp_count_posts( 'press_mention' );
    
    ?>
    <div class="mkp-dashboard-widget">
        <h3><?php esc_html_e( 'Quick Stats', 'mediakit-pro' ); ?></h3>
        <ul class="mkp-dashboard-stats">
            <li>
                <span class="dashicons dashicons-microphone"></span>
                <strong><?php echo esc_html( $speaking_topics->publish ); ?></strong> <?php esc_html_e( 'Speaking Topics', 'mediakit-pro' ); ?>
                <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=speaking_topic' ) ); ?>" class="button button-small"><?php esc_html_e( 'View', 'mediakit-pro' ); ?></a>
            </li>
            <li>
                <span class="dashicons dashicons-format-video"></span>
                <strong><?php echo esc_html( $media_appearances->publish ); ?></strong> <?php esc_html_e( 'Media Appearances', 'mediakit-pro' ); ?>
                <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=media_appearance' ) ); ?>" class="button button-small"><?php esc_html_e( 'View', 'mediakit-pro' ); ?></a>
            </li>
            <li>
                <span class="dashicons dashicons-portfolio"></span>
                <strong><?php echo esc_html( $portfolio_items->publish ); ?></strong> <?php esc_html_e( 'Portfolio Items', 'mediakit-pro' ); ?>
                <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=portfolio_item' ) ); ?>" class="button button-small"><?php esc_html_e( 'View', 'mediakit-pro' ); ?></a>
            </li>
            <li>
                <span class="dashicons dashicons-format-quote"></span>
                <strong><?php echo esc_html( $testimonials->publish ); ?></strong> <?php esc_html_e( 'Testimonials', 'mediakit-pro' ); ?>
                <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=testimonial' ) ); ?>" class="button button-small"><?php esc_html_e( 'View', 'mediakit-pro' ); ?></a>
            </li>
            <li>
                <span class="dashicons dashicons-media-document"></span>
                <strong><?php echo esc_html( $press_mentions->publish ); ?></strong> <?php esc_html_e( 'Press Mentions', 'mediakit-pro' ); ?>
                <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=press_mention' ) ); ?>" class="button button-small"><?php esc_html_e( 'View', 'mediakit-pro' ); ?></a>
            </li>
        </ul>
        
        <h3><?php esc_html_e( 'Quick Actions', 'mediakit-pro' ); ?></h3>
        <div class="mkp-dashboard-actions">
            <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=speaking_topic' ) ); ?>" class="button button-primary"><?php esc_html_e( 'Add Speaking Topic', 'mediakit-pro' ); ?></a>
            <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=media_appearance' ) ); ?>" class="button"><?php esc_html_e( 'Add Media Appearance', 'mediakit-pro' ); ?></a>
            <a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>" class="button"><?php esc_html_e( 'Customize Theme', 'mediakit-pro' ); ?></a>
        </div>
        
        <?php
        // Get recent downloads if tracking is enabled
        $recent_downloads = get_option( 'mkp_recent_downloads', array() );
        if ( ! empty( $recent_downloads ) ) : ?>
            <h3><?php esc_html_e( 'Recent Downloads', 'mediakit-pro' ); ?></h3>
            <ul class="mkp-recent-downloads">
                <?php foreach ( array_slice( $recent_downloads, 0, 5 ) as $download ) : ?>
                    <li>
                        <?php echo esc_html( $download['file'] ); ?> - 
                        <time><?php echo esc_html( human_time_diff( $download['time'], current_time( 'timestamp' ) ) ); ?> <?php esc_html_e( 'ago', 'mediakit-pro' ); ?></time>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
    
    <style>
        .mkp-dashboard-stats {
            margin: 0;
        }
        .mkp-dashboard-stats li {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .mkp-dashboard-stats li:last-child {
            border-bottom: none;
        }
        .mkp-dashboard-stats .dashicons {
            color: #0073aa;
        }
        .mkp-dashboard-stats strong {
            font-size: 18px;
        }
        .mkp-dashboard-stats .button {
            margin-left: auto;
        }
        .mkp-dashboard-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        .mkp-recent-downloads {
            margin: 0;
        }
        .mkp-recent-downloads li {
            padding: 5px 0;
            font-size: 13px;
        }
    </style>
    <?php
}

/**
 * Add admin menu pages
 */
function mkp_add_admin_menu() {
    // Main menu
    add_menu_page(
        __( 'Media Kit', 'mediakit-pro' ),
        __( 'Media Kit', 'mediakit-pro' ),
        'manage_options',
        'mediakit-pro',
        'mkp_admin_page_display',
        'dashicons-id-alt',
        30
    );
    
    // Overview submenu
    add_submenu_page(
        'mediakit-pro',
        __( 'Media Kit Overview', 'mediakit-pro' ),
        __( 'Overview', 'mediakit-pro' ),
        'manage_options',
        'mediakit-pro',
        'mkp_admin_page_display'
    );
    
    // Add a divider
    add_submenu_page(
        'mediakit-pro',
        '<span style="display:block; margin:1px 0 1px -5px; padding:0; height:1px; line-height:1px; background:#CCC;"></span>',
        '',
        'read',
        '#',
        ''
    );
    
    // Stats submenu
    add_submenu_page(
        'mediakit-pro',
        __( 'Download Statistics', 'mediakit-pro' ),
        __( 'Download Stats', 'mediakit-pro' ),
        'manage_options',
        'mediakit-pro-stats',
        'mkp_stats_page_display'
    );
    
    // Import/Export submenu
    add_submenu_page(
        'mediakit-pro',
        __( 'Import/Export', 'mediakit-pro' ),
        __( 'Import/Export', 'mediakit-pro' ),
        'manage_options',
        'mediakit-pro-import-export',
        'mkp_import_export_page_display'
    );
}
add_action( 'admin_menu', 'mkp_add_admin_menu', 5 );

/**
 * Reorder admin submenu items
 */
function mkp_reorder_admin_menu( $menu_order ) {
    global $submenu;
    
    if ( isset( $submenu['mediakit-pro'] ) ) {
        // Define the desired order
        $new_order = array();
        
        // Keep Overview first
        $new_order[] = $submenu['mediakit-pro'][0];
        
        // Group content types
        foreach ( $submenu['mediakit-pro'] as $item ) {
            if ( strpos( $item[2], 'edit.php?post_type=speaking_topic' ) !== false ) {
                $new_order[] = $item;
            }
        }
        foreach ( $submenu['mediakit-pro'] as $item ) {
            if ( strpos( $item[2], 'edit.php?post_type=media_appearance' ) !== false ) {
                $new_order[] = $item;
            }
        }
        foreach ( $submenu['mediakit-pro'] as $item ) {
            if ( strpos( $item[2], 'edit.php?post_type=portfolio_item' ) !== false ) {
                $new_order[] = $item;
            }
        }
        foreach ( $submenu['mediakit-pro'] as $item ) {
            if ( strpos( $item[2], 'edit.php?post_type=testimonial' ) !== false ) {
                $new_order[] = $item;
            }
        }
        foreach ( $submenu['mediakit-pro'] as $item ) {
            if ( strpos( $item[2], 'edit.php?post_type=press_mention' ) !== false ) {
                $new_order[] = $item;
            }
        }
        
        // Add taxonomies
        foreach ( $submenu['mediakit-pro'] as $item ) {
            if ( strpos( $item[2], 'edit-tags.php' ) !== false ) {
                $new_order[] = $item;
            }
        }
        
        // Add divider and other items
        foreach ( $submenu['mediakit-pro'] as $item ) {
            if ( ! in_array( $item, $new_order ) ) {
                $new_order[] = $item;
            }
        }
        
        $submenu['mediakit-pro'] = $new_order;
    }
    
    return $menu_order;
}
add_filter( 'custom_menu_order', '__return_true' );
add_filter( 'menu_order', 'mkp_reorder_admin_menu' );

/**
 * Display main admin page
 */
function mkp_admin_page_display() {
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        
        <div class="mkp-admin-page">
            <div class="mkp-admin-welcome">
                <h2><?php esc_html_e( 'Welcome to MediaKit Pro', 'mediakit-pro' ); ?></h2>
                <p><?php esc_html_e( 'Your professional media kit theme is ready to showcase your work. Follow these steps to get started:', 'mediakit-pro' ); ?></p>
            </div>
            
            <div class="mkp-admin-cards">
                <div class="mkp-admin-card">
                    <h3>1. <?php esc_html_e( 'Customize Your Brand', 'mediakit-pro' ); ?></h3>
                    <p><?php esc_html_e( 'Set your colors, fonts, and upload your logo.', 'mediakit-pro' ); ?></p>
                    <a href="<?php echo esc_url( admin_url( 'customize.php?autofocus[section]=mkp_brand_settings' ) ); ?>" class="button button-primary"><?php esc_html_e( 'Customize Brand', 'mediakit-pro' ); ?></a>
                </div>
                
                <div class="mkp-admin-card">
                    <h3>2. <?php esc_html_e( 'Add Your Content', 'mediakit-pro' ); ?></h3>
                    <p><?php esc_html_e( 'Add speaking topics, media appearances, and testimonials.', 'mediakit-pro' ); ?></p>
                    <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=speaking_topic' ) ); ?>" class="button"><?php esc_html_e( 'Add Content', 'mediakit-pro' ); ?></a>
                </div>
                
                <div class="mkp-admin-card">
                    <h3>3. <?php esc_html_e( 'Configure Hero Section', 'mediakit-pro' ); ?></h3>
                    <p><?php esc_html_e( 'Set up your homepage hero with background and text.', 'mediakit-pro' ); ?></p>
                    <a href="<?php echo esc_url( admin_url( 'customize.php?autofocus[section]=mkp_hero_section' ) ); ?>" class="button"><?php esc_html_e( 'Setup Hero', 'mediakit-pro' ); ?></a>
                </div>
                
                <div class="mkp-admin-card">
                    <h3>4. <?php esc_html_e( 'Add Social Links', 'mediakit-pro' ); ?></h3>
                    <p><?php esc_html_e( 'Connect your social media profiles.', 'mediakit-pro' ); ?></p>
                    <a href="<?php echo esc_url( admin_url( 'customize.php?autofocus[section]=mkp_social_media' ) ); ?>" class="button"><?php esc_html_e( 'Add Social Links', 'mediakit-pro' ); ?></a>
                </div>
            </div>
            
            <div class="mkp-admin-resources">
                <h2><?php esc_html_e( 'Resources', 'mediakit-pro' ); ?></h2>
                <ul>
                    <li><a href="#" target="_blank"><?php esc_html_e( 'Theme Documentation', 'mediakit-pro' ); ?></a></li>
                    <li><a href="#" target="_blank"><?php esc_html_e( 'Video Tutorials', 'mediakit-pro' ); ?></a></li>
                    <li><a href="#" target="_blank"><?php esc_html_e( 'Support Forum', 'mediakit-pro' ); ?></a></li>
                </ul>
            </div>
        </div>
    </div>
    
    <style>
        .mkp-admin-page {
            max-width: 1200px;
            margin-top: 20px;
        }
        .mkp-admin-welcome {
            background: #fff;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid #ccd0d4;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        .mkp-admin-welcome h2 {
            margin-top: 0;
            font-size: 28px;
        }
        .mkp-admin-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .mkp-admin-card {
            background: #fff;
            padding: 20px;
            border: 1px solid #ccd0d4;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        .mkp-admin-card h3 {
            margin-top: 0;
        }
        .mkp-admin-resources {
            background: #fff;
            padding: 20px;
            border: 1px solid #ccd0d4;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        .mkp-admin-resources h2 {
            margin-top: 0;
        }
        .mkp-admin-resources ul {
            margin: 0;
            list-style: disc;
            padding-left: 20px;
        }
    </style>
    <?php
}

/**
 * Display statistics page
 */
function mkp_stats_page_display() {
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        
        <div class="mkp-stats-page">
            <?php
            // Get download statistics
            $downloads = get_option( 'mkp_download_stats', array() );
            
            if ( empty( $downloads ) ) {
                echo '<p>' . esc_html__( 'No download statistics available yet.', 'mediakit-pro' ) . '</p>';
            } else {
                ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'File', 'mediakit-pro' ); ?></th>
                            <th><?php esc_html_e( 'Downloads', 'mediakit-pro' ); ?></th>
                            <th><?php esc_html_e( 'Last Downloaded', 'mediakit-pro' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $downloads as $file_id => $data ) : ?>
                            <tr>
                                <td><?php echo esc_html( get_the_title( $file_id ) ); ?></td>
                                <td><?php echo esc_html( $data['count'] ); ?></td>
                                <td>
                                    <?php 
                                    if ( isset( $data['last_download'] ) ) {
                                        echo esc_html( human_time_diff( $data['last_download'], current_time( 'timestamp' ) ) . ' ' . __( 'ago', 'mediakit-pro' ) );
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php
            }
            ?>
        </div>
    </div>
    <?php
}

/**
 * Display import/export page
 */
function mkp_import_export_page_display() {
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        
        <div class="mkp-import-export-page">
            <div class="mkp-export-section">
                <h2><?php esc_html_e( 'Export Media Kit', 'mediakit-pro' ); ?></h2>
                <p><?php esc_html_e( 'Export your media kit content to a file that can be imported into another WordPress site.', 'mediakit-pro' ); ?></p>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <?php wp_nonce_field( 'mkp_export_nonce' ); ?>
                    <input type="hidden" name="action" value="mkp_export_media_kit">
                    <p>
                        <label>
                            <input type="checkbox" name="export_speaking_topics" value="1" checked>
                            <?php esc_html_e( 'Include Speaking Topics', 'mediakit-pro' ); ?>
                        </label>
                    </p>
                    <p>
                        <label>
                            <input type="checkbox" name="export_media_appearances" value="1" checked>
                            <?php esc_html_e( 'Include Media Appearances', 'mediakit-pro' ); ?>
                        </label>
                    </p>
                    <p>
                        <label>
                            <input type="checkbox" name="export_testimonials" value="1" checked>
                            <?php esc_html_e( 'Include Testimonials', 'mediakit-pro' ); ?>
                        </label>
                    </p>
                    <p>
                        <label>
                            <input type="checkbox" name="export_press" value="1" checked>
                            <?php esc_html_e( 'Include Press Mentions', 'mediakit-pro' ); ?>
                        </label>
                    </p>
                    <p>
                        <label>
                            <input type="checkbox" name="export_portfolio" value="1" checked>
                            <?php esc_html_e( 'Include Portfolio Items', 'mediakit-pro' ); ?>
                        </label>
                    </p>
                    <p class="submit">
                        <input type="submit" class="button button-primary" value="<?php esc_attr_e( 'Export Media Kit', 'mediakit-pro' ); ?>">
                    </p>
                </form>
            </div>
            
            <hr>
            
            <div class="mkp-import-section">
                <h2><?php esc_html_e( 'Import Media Kit', 'mediakit-pro' ); ?></h2>
                <p><?php esc_html_e( 'Import media kit content from an export file.', 'mediakit-pro' ); ?></p>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
                    <?php wp_nonce_field( 'mkp_import_nonce' ); ?>
                    <input type="hidden" name="action" value="mkp_import_media_kit">
                    <p>
                        <label for="import_file"><?php esc_html_e( 'Choose file:', 'mediakit-pro' ); ?></label>
                        <input type="file" name="import_file" id="import_file" accept=".json">
                    </p>
                    <p class="submit">
                        <input type="submit" class="button button-primary" value="<?php esc_attr_e( 'Import Media Kit', 'mediakit-pro' ); ?>">
                    </p>
                </form>
            </div>
            
            <hr>
            
            <div class="mkp-demo-content-section">
                <h2><?php esc_html_e( 'Demo Content', 'mediakit-pro' ); ?></h2>
                <p><?php esc_html_e( 'Install demo content to see how the theme works.', 'mediakit-pro' ); ?></p>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <?php wp_nonce_field( 'mkp_demo_content_nonce' ); ?>
                    <input type="hidden" name="action" value="mkp_install_demo_content">
                    <p class="submit">
                        <input type="submit" class="button" value="<?php esc_attr_e( 'Install Demo Content', 'mediakit-pro' ); ?>" onclick="return confirm('<?php esc_attr_e( 'This will create sample posts and pages. Continue?', 'mediakit-pro' ); ?>');">
                    </p>
                </form>
            </div>
        </div>
    </div>
    
    <style>
        .mkp-import-export-page {
            max-width: 800px;
            background: #fff;
            padding: 20px;
            margin-top: 20px;
            border: 1px solid #ccd0d4;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        .mkp-import-export-page hr {
            margin: 30px 0;
        }
    </style>
    <?php
}

/**
 * Add custom columns to post types
 */
function mkp_add_custom_columns( $columns ) {
    $new_columns = array();
    
    foreach ( $columns as $key => $value ) {
        if ( $key === 'title' ) {
            $new_columns[ $key ] = $value;
            $new_columns['thumbnail'] = __( 'Thumbnail', 'mediakit-pro' );
        } else {
            $new_columns[ $key ] = $value;
        }
    }
    
    return $new_columns;
}
add_filter( 'manage_speaking_topic_posts_columns', 'mkp_add_custom_columns' );
add_filter( 'manage_media_appearance_posts_columns', 'mkp_add_custom_columns' );
add_filter( 'manage_portfolio_item_posts_columns', 'mkp_add_custom_columns' );
add_filter( 'manage_testimonial_posts_columns', 'mkp_add_custom_columns' );
add_filter( 'manage_press_mention_posts_columns', 'mkp_add_custom_columns' );

/**
 * Display custom column content
 */
function mkp_custom_column_content( $column, $post_id ) {
    if ( $column === 'thumbnail' ) {
        if ( has_post_thumbnail( $post_id ) ) {
            echo get_the_post_thumbnail( $post_id, array( 50, 50 ) );
        } else {
            echo '<span class="dashicons dashicons-format-image" style="font-size: 40px; width: 50px; height: 50px; color: #ddd;"></span>';
        }
    }
}
add_action( 'manage_speaking_topic_posts_custom_column', 'mkp_custom_column_content', 10, 2 );
add_action( 'manage_media_appearance_posts_custom_column', 'mkp_custom_column_content', 10, 2 );
add_action( 'manage_portfolio_item_posts_custom_column', 'mkp_custom_column_content', 10, 2 );
add_action( 'manage_testimonial_posts_custom_column', 'mkp_custom_column_content', 10, 2 );
add_action( 'manage_press_mention_posts_custom_column', 'mkp_custom_column_content', 10, 2 );

/**
 * Add theme info to admin footer
 */
function mkp_admin_footer_text( $text ) {
    $screen = get_current_screen();
    
    if ( strpos( $screen->id, 'mediakit-pro' ) !== false || 
         in_array( $screen->post_type, array( 'speaking_topic', 'media_appearance', 'portfolio_item', 'testimonial', 'press_mention' ) ) ) {
        $text = sprintf(
            __( 'Thank you for using <strong>MediaKit Pro</strong>. <a href="%s" target="_blank">Leave a review</a>', 'mediakit-pro' ),
            '#'
        );
    }
    
    return $text;
}
add_filter( 'admin_footer_text', 'mkp_admin_footer_text' );

/**
 * Enqueue admin styles
 */
function mkp_admin_styles() {
    $screen = get_current_screen();
    
    if ( strpos( $screen->id, 'mediakit-pro' ) !== false || 
         in_array( $screen->post_type, array( 'speaking_topic', 'media_appearance', 'portfolio_item', 'testimonial', 'press_mention' ) ) ) {
        wp_enqueue_style( 'mediakit-pro-admin', get_template_directory_uri() . '/assets/css/admin.css', array(), MKP_THEME_VERSION );
    }
}
add_action( 'admin_enqueue_scripts', 'mkp_admin_styles' );

/**
 * Add theme setup wizard
 */
function mkp_theme_activation_redirect() {
    global $pagenow;
    
    if ( is_admin() && 'themes.php' == $pagenow && isset( $_GET['activated'] ) ) {
        wp_redirect( admin_url( 'admin.php?page=mediakit-pro' ) );
        exit;
    }
}
add_action( 'admin_init', 'mkp_theme_activation_redirect' );