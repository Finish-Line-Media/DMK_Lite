<?php
/**
 * Template Name: Speaker Page
 * Template Post Type: page
 * Description: For speaking topics and booking information
 *
 * @package MediaKit_Pro
 */

get_header();
?>

<main id="primary" class="mkp-main mkp-main--speaker">
    
    <?php while ( have_posts() ) : the_post(); ?>
        
        <!-- Hero Section -->
        <section class="mkp-speaker-hero">
            <div class="mkp-container">
                <div class="mkp-speaker-hero__content">
                    <h1 class="mkp-speaker-hero__title"><?php the_title(); ?></h1>
                    <?php if ( has_excerpt() ) : ?>
                        <div class="mkp-speaker-hero__subtitle"><?php the_excerpt(); ?></div>
                    <?php endif; ?>
                    
                    <div class="mkp-speaker-hero__buttons">
                        <?php
                        $booking_link = get_theme_mod( 'mkp_booking_calendar_link' );
                        if ( $booking_link ) :
                            ?>
                            <a href="<?php echo esc_url( $booking_link ); ?>" class="mkp-btn mkp-btn--primary" target="_blank">
                                <?php esc_html_e( 'Check Availability', 'mediakit-pro' ); ?>
                            </a>
                        <?php endif; ?>
                        
                        <a href="#speaking-topics" class="mkp-btn mkp-btn--secondary">
                            <?php esc_html_e( 'View Speaking Topics', 'mediakit-pro' ); ?>
                        </a>
                    </div>
                </div>
                
                <?php if ( has_post_thumbnail() ) : ?>
                    <div class="mkp-speaker-hero__image">
                        <?php the_post_thumbnail( 'mkp-hero' ); ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        
        <!-- Page Content -->
        <?php if ( get_the_content() ) : ?>
            <section class="mkp-section">
                <div class="mkp-container">
                    <div class="mkp-speaker-content">
                        <?php the_content(); ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
        
        <!-- Speaking Topics -->
        <section id="speaking-topics" class="mkp-section mkp-section--alt">
            <div class="mkp-container">
                <header class="mkp-section__header">
                    <h2 class="mkp-section__title"><?php esc_html_e( 'Speaking Topics', 'mediakit-pro' ); ?></h2>
                    <p class="mkp-section__subtitle"><?php esc_html_e( 'Inspiring presentations tailored to your audience', 'mediakit-pro' ); ?></p>
                </header>
                
                <?php
                $speaking_topics = new WP_Query( array(
                    'post_type'      => 'speaking_topic',
                    'posts_per_page' => -1,
                    'orderby'        => 'menu_order',
                    'order'          => 'ASC',
                ) );
                
                if ( $speaking_topics->have_posts() ) :
                    ?>
                    <div class="mkp-speaker-topics">
                        <?php
                        while ( $speaking_topics->have_posts() ) :
                            $speaking_topics->the_post();
                            ?>
                            <article class="mkp-speaker-topic">
                                <?php if ( has_post_thumbnail() ) : ?>
                                    <div class="mkp-speaker-topic__image">
                                        <?php the_post_thumbnail( 'mkp-portfolio' ); ?>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="mkp-speaker-topic__content">
                                    <h3 class="mkp-speaker-topic__title"><?php the_title(); ?></h3>
                                    
                                    <div class="mkp-speaker-topic__excerpt">
                                        <?php the_excerpt(); ?>
                                    </div>
                                    
                                    <?php if ( function_exists( 'get_field' ) ) : ?>
                                        <?php
                                        $target_audience = get_field( 'target_audience' );
                                        $duration = get_field( 'duration' );
                                        $key_takeaways = get_field( 'key_takeaways' );
                                        ?>
                                        
                                        <div class="mkp-speaker-topic__meta">
                                            <?php if ( $target_audience ) : ?>
                                                <div class="mkp-speaker-topic__audience">
                                                    <strong><?php esc_html_e( 'Audience:', 'mediakit-pro' ); ?></strong>
                                                    <?php echo esc_html( $target_audience ); ?>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <?php if ( $duration ) : ?>
                                                <div class="mkp-speaker-topic__duration">
                                                    <strong><?php esc_html_e( 'Duration:', 'mediakit-pro' ); ?></strong>
                                                    <?php echo esc_html( $duration ); ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <?php if ( $key_takeaways ) : ?>
                                            <div class="mkp-speaker-topic__takeaways">
                                                <h4><?php esc_html_e( 'Key Takeaways:', 'mediakit-pro' ); ?></h4>
                                                <ul>
                                                    <?php foreach ( $key_takeaways as $takeaway ) : ?>
                                                        <li><?php echo esc_html( $takeaway['takeaway'] ); ?></li>
                                                    <?php endforeach; ?>
                                                </ul>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    
                                    <a href="<?php the_permalink(); ?>" class="mkp-btn mkp-btn--text">
                                        <?php esc_html_e( 'Learn More', 'mediakit-pro' ); ?> &rarr;
                                    </a>
                                </div>
                            </article>
                            <?php
                        endwhile;
                        wp_reset_postdata();
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        
        <!-- Speaking Stats -->
        <?php if ( function_exists( 'get_field' ) && have_rows( 'speaking_stats', 'option' ) ) : ?>
            <section class="mkp-section">
                <div class="mkp-container">
                    <div class="mkp-stats">
                        <div class="mkp-grid mkp-grid--4">
                            <?php while ( have_rows( 'speaking_stats', 'option' ) ) : the_row(); ?>
                                <div class="mkp-stats__item">
                                    <div class="mkp-stats__number"><?php the_sub_field( 'number' ); ?></div>
                                    <div class="mkp-stats__label"><?php the_sub_field( 'label' ); ?></div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif; ?>
        
        <!-- Testimonials -->
        <?php
        $testimonials = new WP_Query( array(
            'post_type'      => 'testimonial',
            'posts_per_page' => 3,
            'orderby'        => 'rand',
        ) );
        
        if ( $testimonials->have_posts() ) :
            ?>
            <section class="mkp-section mkp-section--alt">
                <div class="mkp-container">
                    <header class="mkp-section__header">
                        <h2 class="mkp-section__title"><?php esc_html_e( 'What People Say', 'mediakit-pro' ); ?></h2>
                    </header>
                    
                    <div class="mkp-grid mkp-grid--3">
                        <?php
                        while ( $testimonials->have_posts() ) :
                            $testimonials->the_post();
                            get_template_part( 'template-parts/content', 'testimonial' );
                        endwhile;
                        wp_reset_postdata();
                        ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
        
        <!-- Booking CTA -->
        <section class="mkp-section mkp-speaker-cta">
            <div class="mkp-container">
                <div class="mkp-speaker-cta__content">
                    <h2><?php esc_html_e( 'Ready to Inspire Your Audience?', 'mediakit-pro' ); ?></h2>
                    <p><?php esc_html_e( 'Let\'s discuss how I can bring value to your next event.', 'mediakit-pro' ); ?></p>
                    
                    <div class="mkp-speaker-cta__buttons">
                        <?php if ( $booking_link ) : ?>
                            <a href="<?php echo esc_url( $booking_link ); ?>" class="mkp-btn mkp-btn--primary mkp-btn--large" target="_blank">
                                <?php esc_html_e( 'Book Me to Speak', 'mediakit-pro' ); ?>
                            </a>
                        <?php endif; ?>
                        
                        <?php
                        $booking_email = get_theme_mod( 'mkp_contact_email_booking' );
                        if ( $booking_email ) :
                            ?>
                            <a href="mailto:<?php echo esc_attr( $booking_email ); ?>" class="mkp-btn mkp-btn--secondary mkp-btn--large">
                                <?php esc_html_e( 'Contact for Booking', 'mediakit-pro' ); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
        
    <?php endwhile; ?>
    
</main>

<?php
get_footer();