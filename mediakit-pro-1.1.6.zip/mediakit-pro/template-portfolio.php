<?php
/**
 * Template Name: Portfolio Gallery
 * Template Post Type: page
 * Description: Visual grid layout for portfolio items
 *
 * @package MediaKit_Pro
 */

get_header();
?>

<main id="primary" class="mkp-main mkp-main--portfolio">
    
    <?php while ( have_posts() ) : the_post(); ?>
        
        <!-- Page Header -->
        <section class="mkp-page-header mkp-page-header--centered">
            <div class="mkp-container">
                <h1 class="mkp-page-title"><?php the_title(); ?></h1>
                <?php if ( has_excerpt() ) : ?>
                    <div class="mkp-page-subtitle"><?php the_excerpt(); ?></div>
                <?php endif; ?>
            </div>
        </section>
        
        <!-- Page Content -->
        <?php if ( get_the_content() ) : ?>
            <section class="mkp-section">
                <div class="mkp-container">
                    <div class="mkp-portfolio-intro">
                        <?php the_content(); ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
        
        <!-- Portfolio Filter -->
        <?php
        $portfolio_categories = get_terms( array(
            'taxonomy'   => 'portfolio_category',
            'hide_empty' => true,
        ) );
        
        if ( ! empty( $portfolio_categories ) && ! is_wp_error( $portfolio_categories ) ) :
            ?>
            <section class="mkp-portfolio-filter">
                <div class="mkp-container">
                    <div class="mkp-filter-buttons" data-filter-group="category">
                        <button class="mkp-filter-button is-active" data-filter="*">
                            <?php esc_html_e( 'All', 'mediakit-pro' ); ?>
                        </button>
                        <?php foreach ( $portfolio_categories as $category ) : ?>
                            <button class="mkp-filter-button" data-filter=".portfolio-category-<?php echo esc_attr( $category->slug ); ?>">
                                <?php echo esc_html( $category->name ); ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
        
        <!-- Portfolio Grid -->
        <section class="mkp-section">
            <div class="mkp-container">
                <?php
                $portfolio_items = new WP_Query( array(
                    'post_type'      => 'portfolio_item',
                    'posts_per_page' => -1,
                    'orderby'        => 'menu_order date',
                    'order'          => 'DESC',
                ) );
                
                if ( $portfolio_items->have_posts() ) :
                    ?>
                    <div class="mkp-portfolio-grid">
                        <?php
                        while ( $portfolio_items->have_posts() ) :
                            $portfolio_items->the_post();
                            
                            $categories = get_the_terms( get_the_ID(), 'portfolio_category' );
                            $category_classes = '';
                            
                            if ( $categories && ! is_wp_error( $categories ) ) {
                                foreach ( $categories as $category ) {
                                    $category_classes .= ' portfolio-category-' . $category->slug;
                                }
                            }
                            ?>
                            
                            <article class="mkp-portfolio-item<?php echo esc_attr( $category_classes ); ?>">
                                <a href="<?php the_permalink(); ?>" class="mkp-portfolio-item__link">
                                    <?php if ( has_post_thumbnail() ) : ?>
                                        <div class="mkp-portfolio-item__image">
                                            <?php the_post_thumbnail( 'mkp-portfolio' ); ?>
                                            <div class="mkp-portfolio-item__overlay">
                                                <span class="mkp-portfolio-item__icon">+</span>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="mkp-portfolio-item__content">
                                        <h3 class="mkp-portfolio-item__title"><?php the_title(); ?></h3>
                                        
                                        <?php if ( $categories && ! is_wp_error( $categories ) ) : ?>
                                            <div class="mkp-portfolio-item__categories">
                                                <?php
                                                $category_names = wp_list_pluck( $categories, 'name' );
                                                echo esc_html( implode( ', ', $category_names ) );
                                                ?>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if ( function_exists( 'get_field' ) ) : ?>
                                            <?php
                                            $client = get_field( 'client_name' );
                                            if ( $client ) :
                                                ?>
                                                <div class="mkp-portfolio-item__client">
                                                    <?php echo esc_html( $client ); ?>
                                                </div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            </article>
                            
                            <?php
                        endwhile;
                        wp_reset_postdata();
                        ?>
                    </div>
                <?php else : ?>
                    <p><?php esc_html_e( 'No portfolio items found.', 'mediakit-pro' ); ?></p>
                <?php endif; ?>
            </div>
        </section>
        
    <?php endwhile; ?>
    
</main>

<?php
get_footer();