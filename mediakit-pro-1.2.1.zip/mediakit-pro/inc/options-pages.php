<?php
/**
 * Options Pages for MediaKit Pro
 *
 * @package MediaKit_Pro
 */

// This file has been emptied as the options pages have been removed